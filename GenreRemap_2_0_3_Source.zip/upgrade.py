from pathlib import Path
import json,re
p=Path('/mnt/data/gr2000/src/ui.ts')
s=p.read_text()
# Version display and CSS responsive sidebar
s=s.replace('BUILD 1.9.11.0','BUILD 2.0.0')
# Insert CSS before closing style
css='''
  /* Genre Remap 2.0.0 — compact Studio Interface */
  #app{grid-template-columns:190px minmax(0,1fr)!important}
  #sidebar{padding:16px 9px 10px!important;gap:12px!important}
  #brandMark{width:48px!important;height:48px!important}
  .title{font-size:18px!important}.subtitle{font-size:10px!important}
  .section-label{font-size:10px!important;letter-spacing:.8px!important}
  .genre-list{gap:3px!important}
  .genre{min-height:32px!important;padding:6px 7px!important;gap:8px!important;font-size:12px!important;white-space:nowrap!important}
  .genre:before{width:11px!important;height:11px!important;flex-basis:11px!important}
  #actionCard{padding:9px!important;gap:6px!important}
  #actionCard h2{font-size:11px!important;margin:0 0 2px!important}
  #main{display:flex!important;flex-direction:column!important;gap:9px!important;overflow:hidden!important;min-height:0!important}
  #midiCard{flex:0 0 auto!important}
  #sequencerCard{flex:1 1 auto!important;min-height:210px!important;min-width:0!important}
  #bottomGrid{display:flex!important;flex:0 0 270px!important;flex-direction:column!important;min-height:0!important;gap:6px!important;overflow:hidden!important}
  .studio-tabs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;flex:0 0 auto}
  .studio-tab{border:1px solid #3b4b60;background:#1a2431;color:#cbd7e6;border-radius:6px;padding:8px 10px;font-size:11px;font-weight:750;letter-spacing:.04em;cursor:pointer}
  .studio-tab[aria-selected="true"]{background:#43291f;border-color:#e45b20;color:#ffb17e}
  .studio-panel{display:none;flex:1 1 auto;min-height:0;overflow:auto;overscroll-behavior:contain;scrollbar-width:thin;gap:8px;padding:1px 3px 4px 0}
  .studio-panel.active{display:flex;flex-wrap:wrap;align-content:flex-start}
  .studio-panel>.bottom-card{display:block!important;box-sizing:border-box!important;flex:1 1 220px!important;width:auto!important;height:auto!important;min-height:0!important;max-height:none!important;overflow:visible!important;padding:10px!important}
  #studio-remap #fillEngineCard{flex:2 1 360px!important}
  #studio-groove #grooveCard{display:flex!important;flex-direction:column!important;flex:1 1 100%!important;gap:7px!important}
  #studio-audio #audioControls{display:grid;grid-template-columns:minmax(180px,.8fr) minmax(260px,1.2fr);gap:8px;width:100%;align-items:start}
  #audioControls>.audio-group{border:1px solid #344354;border-radius:7px;background:#151d28;padding:8px;min-width:0}
  #audioControls .mixer-panel{margin:5px 0}
  @media(max-height:760px){#bottomGrid{flex-basis:235px!important}#sequencerCard{min-height:180px!important}.studio-tab{padding:6px}}
  @media(max-width:900px){#app{grid-template-columns:170px minmax(0,1fr)!important}.genre{font-size:11px!important}.studio-panel>.bottom-card{flex-basis:100%!important}#audioControls{grid-template-columns:1fr!important}}
  @media(max-width:650px){#app{grid-template-columns:145px minmax(0,1fr)!important}.genre{font-size:10px!important;padding:5px!important}.studio-panel>.bottom-card{flex-basis:100%!important}}
'''
s=s.replace('</style>',css+'\n</style>',1)
# replace bottom grid start with tab nav/panels
s=s.replace('  <div id="bottomGrid">','''  <div id="bottomGrid">
   <nav class="studio-tabs" role="tablist" aria-label="Studio settings">
    <button class="studio-tab" type="button" role="tab" data-studio-tab="remap" aria-selected="true">REMAP</button>
    <button class="studio-tab" type="button" role="tab" data-studio-tab="groove" aria-selected="false">GROOVE</button>
    <button class="studio-tab" type="button" role="tab" data-studio-tab="audio" aria-selected="false">AUDIO</button>
   </nav>
   <div class="studio-panel active" id="studio-remap" role="tabpanel"></div>
   <div class="studio-panel" id="studio-groove" role="tabpanel"></div>
   <div class="studio-panel" id="studio-audio" role="tabpanel"></div>''')
# Move panels after helper declaration, before rest of app init
needle='const $=id=>document.getElementById(id);'
insert='''const $=id=>document.getElementById(id);
// Recompose existing controls into Studio tabs without recreating controls or changing their IDs.
(function setupStudioInterface(){
 const remap=$('studio-remap'), groove=$('studio-groove'), audio=$('studio-audio');
 const move=(id,parent)=>{const el=$(id);if(el)parent.appendChild(el);};
 ['destinationCard','settingsCard','fillEngineCard'].forEach(id=>move(id,remap));
 const gc=$('grooveCard');
 if(gc){
   const audioWrap=document.createElement('div');audioWrap.id='audioControls';
   const previewGroup=document.createElement('div');previewGroup.className='audio-group';
   const mixerGroup=document.createElement('div');mixerGroup.className='audio-group';
   const grooveGroup=document.createElement('div');grooveGroup.className='audio-group';
   const children=[...gc.children];
   children.forEach(el=>{
     if(el.classList.contains('preview-studio')||el.querySelector?.('#previewVolume'))previewGroup.appendChild(el);
     else if(el.id==='previewMixerPanel')mixerGroup.appendChild(el);
     else if(el.classList.contains('velocity-controls')||el.classList.contains('dynamics-controls')||el.id==='grooveIntelligence')grooveGroup.appendChild(el);
     else if(el.classList.contains('tempo-field')||el.querySelector?.('#loopPreview')||el.querySelector?.('#applyLiveTempo'))previewGroup.appendChild(el);
     else grooveGroup.appendChild(el);
   });
   previewGroup.querySelectorAll('.field').forEach(el=>{if(el.querySelector('#previewVolume'))previewGroup.appendChild(el)});
   audioWrap.append(previewGroup,mixerGroup);audio.appendChild(audioWrap);
   groove.appendChild(grooveGroup);
   gc.remove();
 }
 const tabs=[...document.querySelectorAll('[data-studio-tab]')];
 const activate=name=>{tabs.forEach(b=>b.setAttribute('aria-selected',String(b.dataset.studioTab===name)));['remap','groove','audio'].forEach(k=>$('studio-'+k).classList.toggle('active',k===name));};
 tabs.forEach(b=>b.addEventListener('click',()=>activate(b.dataset.studioTab)));
})();'''
s=s.replace(needle,insert,1)
p.write_text(s)
# sync package + manifest
for fn in ['package.json','manifest.json']:
 q=Path('/mnt/data/gr2000')/fn; d=json.loads(q.read_text());d['version']='2.0.0';q.write_text(json.dumps(d,indent=2)+'\n')
# changelog
ch=Path('/mnt/data/gr2000/CHANGELOG.md')
ch.write_text('''# Genre Remap 2.0.0 — Studio Interface\n\n## GUI redesign\n- Compact left genre navigation: 190 px base width, tighter buttons and spacing; full genre names retained.\n- New REMAP / GROOVE / AUDIO tabs for the existing settings.\n- Remap tab groups target/clip destination, remap intensity and Fill Engine.\n- Groove tab groups Velocity Intelligence, Groove Dynamics and Groove Intelligence.\n- Audio tab groups Original / Processed / Compare, Preview Volume, Drum Mixer, tempo and preview controls.\n- Sequencer receives the flexible central area; settings scroll within their own panel instead of forcing the whole extension to scroll.\n- Existing controls are moved, not recreated; IDs and control logic remain unchanged.\n\n## Preserved\n- MIDI transformation, phrase/fill processing and MIDI clip creation.\n- Velocity layer selection and sensitivity.\n- Original / Processed / Compare audio preview and ten-channel mixer.\n- Existing settings persistence and mapping behavior.\n\n## Validation\n- See build and test results accompanying this release.\n- Actual Ableton Live runtime and listening test still required on the user's Mac.\n'''+ch.read_text())
