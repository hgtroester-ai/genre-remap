Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/DataModelObject.ts
/**
* Base class for all SDK objects.
*
* When the exact type of a received handle is not known in advance, pass `DataModelObject`
* as the `type` argument to {@link ExtensionContext.getObjectFromHandle} — see that
* method for details.
*/
var DataModelObject = class DataModelObject {
	/** @internal */
	constructor(handle, dataModel, objectRegistry) {
		this.handle = handle;
		this.dataModel = dataModel;
		this.objectRegistry = objectRegistry;
	}
	/** The canonical parent of this object in Live's object hierarchy, or `null` if it has none. */
	get parent() {
		const handle = this.dataModel.getObjectCanonicalParent(this.handle);
		return handle ? this.objectRegistry.getObjectFromHandle(handle, DataModelObject) : null;
	}
};
//#endregion
//#region src/transaction.ts
/**
* Invokes an asynchronous data model function inside a transaction, returning
* a promise that resolves when its `onResult` callback fires (or rejects when
* `onError` is invoked).
*
*  @internal
*/
const invokeAsync = (dataModel, fn, ...args) => new Promise((resolve, reject) => {
	dataModel.withinTransaction(() => fn(...args, resolve, reject));
});
/**
* Like {@link invokeAsync}, but for data model functions whose `onResult`
* yields a {@link Handle}. The handle is wrapped as an instance of `T` via
* the object registry before the promise resolves.
*
* @internal
*/
const createAsync = (dataModel, registry, type, fn, ...args) => new Promise((resolve, reject) => {
	dataModel.withinTransaction(() => fn(...args, (handle) => resolve(registry.getObjectFromHandle(handle, type)), reject));
});
//#endregion
//#region src/Clip.ts
/** Represents a clip. */
var Clip = class extends DataModelObject {
	static className = "Clip";
	get name() {
		return this.dataModel.clipGetName(this.handle);
	}
	set name(name) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.clipSetName(this.handle, name);
		});
	}
	get startTime() {
		return this.dataModel.clipGetStartTime(this.handle);
	}
	get endTime() {
		return this.dataModel.clipGetEndTime(this.handle);
	}
	get duration() {
		return this.dataModel.clipGetEndTime(this.handle) - this.dataModel.clipGetStartTime(this.handle);
	}
	get startMarker() {
		return this.dataModel.clipGetStartMarker(this.handle);
	}
	get endMarker() {
		return this.dataModel.clipGetEndMarker(this.handle);
	}
	/**
	* Whether the clip is looped. Enabling looping on an unwarped audio clip
	* automatically enables warping.
	*/
	get looping() {
		return this.dataModel.clipGetLooping(this.handle);
	}
	set looping(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.clipSetLooping(this.handle, value);
		});
	}
	get loopStart() {
		return this.dataModel.clipGetLoopStart(this.handle);
	}
	get loopEnd() {
		return this.dataModel.clipGetLoopEnd(this.handle);
	}
	get color() {
		return this.dataModel.clipGetColor(this.handle);
	}
	set color(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.clipSetColor(this.handle, value);
		});
	}
	get muted() {
		return this.dataModel.clipGetMuted(this.handle);
	}
	set muted(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.clipSetMuted(this.handle, value);
		});
	}
};
//#endregion
//#region src/AudioClip.ts
/** Represents an audio clip. */
var AudioClip = class extends Clip {
	static className = "AudioClip";
	get filePath() {
		return this.dataModel.audioclipGetFilePath(this.handle);
	}
	get warping() {
		return this.dataModel.audioclipGetWarping(this.handle);
	}
	set warping(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.audioclipSetWarping(this.handle, value);
		});
	}
	get warpMode() {
		return this.dataModel.audioclipGetWarpMode(this.handle);
	}
	set warpMode(warpMode) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.audioclipSetWarpMode(this.handle, warpMode);
		});
	}
	get warpMarkers() {
		return this.dataModel.audioclipGetWarpMarkers(this.handle);
	}
};
//#endregion
//#region src/MidiClip.ts
/** Represents a MIDI clip. */
var MidiClip = class extends Clip {
	static className = "MidiClip";
	get notes() {
		return this.dataModel.midiclipGetNotes(this.handle);
	}
	set notes(notes) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.midiclipSetNotes(this.handle, notes);
		});
	}
};
//#endregion
//#region src/ClipSlot.ts
/** A slot in the Session View grid that can hold a clip. */
var ClipSlot = class extends DataModelObject {
	static className = "ClipSlot";
	get clip() {
		const handle = this.dataModel.clipslotGetClip(this.handle);
		return handle ? this.objectRegistry.getObjectFromHandle(handle, Clip) : null;
	}
	/**
	* Deletes the clip in this slot. Await the returned promise to ensure the
	* deletion has been fully processed.
	*/
	deleteClip() {
		return invokeAsync(this.dataModel, this.dataModel.clipslotDeleteClip, this.handle);
	}
	/** @param length - Length of the clip in beats. */
	createMidiClip(length) {
		return createAsync(this.dataModel, this.objectRegistry, MidiClip, this.dataModel.clipslotCreateMidiClip, this.handle, length);
	}
	/**
	* Creates an audio clip in this session slot.
	*
	* @param args.filePath - Absolute path to the audio file.
	* @param args.isWarped - See {@link AudioTrack.createAudioClip}.
	* @param args.loopSettings - See {@link AudioTrack.createAudioClip}.
	*/
	createAudioClip(args) {
		return createAsync(this.dataModel, this.objectRegistry, AudioClip, this.dataModel.clipslotCreateAudioClip, this.handle, {
			filePath: args.filePath,
			isWarped: args.isWarped,
			loopSettings: args.loopSettings
		});
	}
};
//#endregion
//#region src/DeviceParameter.ts
/** Represents a device parameter. */
var DeviceParameter = class extends DataModelObject {
	static className = "DeviceParameter";
	get name() {
		return this.dataModel.deviceParameterGetName(this.handle);
	}
	get min() {
		return this.dataModel.deviceParameterGetInternalMin(this.handle);
	}
	get max() {
		return this.dataModel.deviceParameterGetInternalMax(this.handle);
	}
	get isQuantized() {
		return this.dataModel.deviceParameterGetIsQuantized(this.handle);
	}
	get defaultValue() {
		return this.dataModel.deviceParameterGetDefaultValue(this.handle);
	}
	get valueItems() {
		return this.dataModel.deviceParameterGetValueItems(this.handle);
	}
	getValue() {
		return new Promise((resolve) => {
			this.dataModel.deviceParameterGetInternalValue(this.handle, resolve);
		});
	}
	setValue(value) {
		return new Promise((resolve, reject) => {
			this.dataModel.withinTransaction(() => {
				this.dataModel.deviceParameterSetInternalValue(this.handle, value, resolve, (error) => reject(new Error(error)));
			});
		});
	}
};
//#endregion
//#region src/Device.ts
/** Represents a device. */
var Device = class extends DataModelObject {
	static className = "Device";
	get name() {
		return this.dataModel.deviceGetName(this.handle);
	}
	get parameters() {
		return this.dataModel.deviceGetParameters(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, DeviceParameter));
	}
};
//#endregion
//#region src/TakeLane.ts
/** Represents a take lane. */
var TakeLane = class extends DataModelObject {
	static className = "TakeLane";
	get clips() {
		return this.dataModel.takelaneGetClips(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Clip));
	}
	get name() {
		return this.dataModel.takelaneGetName(this.handle);
	}
	set name(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.takelaneSetName(this.handle, value);
		});
	}
	/**
	* @param startTime - Position in the arrangement in beats.
	* @param duration - Length of the clip in beats.
	*/
	createMidiClip(startTime, duration) {
		return createAsync(this.dataModel, this.objectRegistry, MidiClip, this.dataModel.takelaneCreateMidiClip, this.handle, startTime, duration);
	}
	/**
	* Creates an audio clip on this take lane. See {@link AudioTrack.createAudioClip}
	* for argument semantics.
	*/
	createAudioClip(args) {
		return createAsync(this.dataModel, this.objectRegistry, AudioClip, this.dataModel.takelaneCreateAudioClip, this.handle, {
			duration: args.duration,
			filePath: args.filePath,
			isWarped: args.isWarped,
			loopSettings: args.loopSettings,
			startTime: args.startTime
		});
	}
};
//#endregion
//#region src/TrackMixer.ts
/** Represents the mixer of a track. */
var TrackMixer = class extends DataModelObject {
	static className = "MixerDevice";
	get volume() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.mixerdeviceGetVolume(this.handle), DeviceParameter);
	}
	get panning() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.mixerdeviceGetPanning(this.handle), DeviceParameter);
	}
	get sends() {
		return this.dataModel.mixerdeviceGetSends(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, DeviceParameter));
	}
};
//#endregion
//#region src/Track.ts
/** Represents a track. */
var Track = class Track extends DataModelObject {
	static className = "Track";
	get name() {
		return this.dataModel.trackGetName(this.handle);
	}
	set name(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.trackSetName(this.handle, value);
		});
	}
	get mute() {
		return this.dataModel.trackGetMute(this.handle);
	}
	set mute(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.trackSetMute(this.handle, value);
		});
	}
	get solo() {
		return this.dataModel.trackGetSolo(this.handle);
	}
	set solo(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.trackSetSolo(this.handle, value);
		});
	}
	get mutedViaSolo() {
		return this.dataModel.trackGetMutedViaSolo(this.handle);
	}
	get arm() {
		return this.dataModel.trackGetArm(this.handle);
	}
	set arm(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.trackSetArm(this.handle, value);
		});
	}
	get clipSlots() {
		return this.dataModel.trackGetClipSlots(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, ClipSlot));
	}
	get takeLanes() {
		return this.dataModel.trackGetTakeLanes(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, TakeLane));
	}
	get arrangementClips() {
		return this.dataModel.trackGetArrangementClips(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Clip));
	}
	get groupTrack() {
		const handle = this.dataModel.trackGetGroupTrack(this.handle);
		return handle ? this.objectRegistry.getObjectFromHandle(handle, Track) : null;
	}
	get devices() {
		return this.dataModel.trackGetDevices(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Device));
	}
	get mixer() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.trackGetMixerDevice(this.handle), TrackMixer);
	}
	/** Appended to the end of {@link takeLanes}. */
	createTakeLane() {
		return createAsync(this.dataModel, this.objectRegistry, TakeLane, this.dataModel.trackCreateTakeLane, this.handle);
	}
	/**
	* Inserts a built-in Live device with its default preset into the track's device chain.
	* Only devices native to Live are supported — third-party plug-ins cannot be loaded this way.
	*
	* @param deviceName - The name of the built-in Live device (e.g. `"Reverb"`, `"Auto Filter"`).
	* @param index - Zero-based position in the device chain at which to insert.
	*/
	insertDevice(deviceName, index) {
		return createAsync(this.dataModel, this.objectRegistry, Device, this.dataModel.trackInsertDevice, this.handle, deviceName, BigInt(index));
	}
	/**
	* Deletes a device from this track's device chain. Await the returned
	* promise to ensure the deletion has been fully processed.
	*/
	deleteDevice(device) {
		return invokeAsync(this.dataModel, this.dataModel.trackDeleteDevice, this.handle, device.handle);
	}
	/** The duplicate is inserted directly after the original in the device chain. */
	duplicateDevice(device) {
		return createAsync(this.dataModel, this.objectRegistry, Device, this.dataModel.trackDuplicateDevice, this.handle, device.handle);
	}
	/**
	* Deletes an arrangement clip. For session clips, use {@link ClipSlot.deleteClip}.
	* Await the returned promise to ensure the deletion has been fully processed.
	*/
	deleteClip(clip) {
		return invokeAsync(this.dataModel, this.dataModel.trackDeleteClip, this.handle, clip.handle);
	}
	/**
	* Deletes clips within the range. Clips that overlap a boundary are truncated
	* to the range edge rather than fully deleted.
	*
	* @param startTime - Start of the range in beats.
	* @param endTime - End of the range in beats.
	*/
	clearClipsInRange(startTime, endTime) {
		return invokeAsync(this.dataModel, this.dataModel.trackClearClipsInRange, this.handle, startTime, endTime);
	}
};
//#endregion
//#region src/AudioTrack.ts
/** Represents an audio track. */
var AudioTrack = class extends Track {
	static className = "AudioTrack";
	/**
	* Creates an audio clip from a file in the track's arrangement timeline.
	*
	* @param args.filePath - Absolute path to the audio file.
	* @param args.startTime - Position in the arrangement timeline in beats.
	* @param args.duration - Length of the clip on the arrangement timeline,
	*   in beats. Capped at the sample's natural length for non-looping clips;
	*   looping clips repeat to fill the full length. Defaults to the sample's
	*   natural length at the current tempo when omitted.
	* @param args.isWarped - Whether warping is enabled. Defaults to the clip's
	*   saved `.asd` settings if present, otherwise Live's "Auto-Warp" preference.
	*   Must be provided when `loopSettings` is provided.
	* @param args.loopSettings - Initial loop settings. Requires `isWarped` to be
	*   defined. If `isWarped` is `false`, `loopSettings.looping` must be `false`.
	*
	* @example
	* const clip = await track.createAudioClip({ filePath: '/samples/kick.wav', startTime: 0 });
	*
	* @example
	* const clip = await track.createAudioClip({
	*   filePath: '/samples/ambient.wav',
	*   startTime: 16,
	*   isWarped: false,
	* });
	*
	* @example
	* // Clip view: Start=beat 0, End=beat 2, Loop position=beat 0, Loop length=1 beat.
	* const clip = await track.createAudioClip({
	*   filePath: '/samples/loop.wav',
	*   startTime: 0,
	*   isWarped: true,
	*   loopSettings: { looping: true, startMarker: 0, endMarker: 2, loopStart: 0, loopEnd: 1 },
	* });
	*
	* @example
	* const clip = await track.createAudioClip({
	*   filePath: '/samples/loop.wav',
	*   startTime: 0,
	*   isWarped: true,
	*   duration: 8,
	*   loopSettings: { looping: true, startMarker: 0, endMarker: 2, loopStart: 0, loopEnd: 2 },
	* });
	*/
	createAudioClip(args) {
		return createAsync(this.dataModel, this.objectRegistry, AudioClip, this.dataModel.trackCreateAudioClip, this.handle, {
			duration: args.duration,
			filePath: args.filePath,
			isWarped: args.isWarped,
			loopSettings: args.loopSettings,
			startTime: args.startTime
		});
	}
};
//#endregion
//#region src/CuePoint.ts
/** Represents a cue point. */
var CuePoint = class extends DataModelObject {
	static className = "CuePoint";
	get time() {
		return this.dataModel.cuePointGetTime(this.handle);
	}
	get name() {
		return this.dataModel.cuePointGetName(this.handle);
	}
	set name(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.cuePointSetName(this.handle, value);
		});
	}
};
//#endregion
//#region src/MidiTrack.ts
/** Represents a MIDI track. */
var MidiTrack = class extends Track {
	static className = "MidiTrack";
	/**
	* @param startTime - Position in the arrangement in beats.
	* @param duration - Length of the clip in beats.
	*/
	createMidiClip(startTime, duration) {
		return createAsync(this.dataModel, this.objectRegistry, MidiClip, this.dataModel.trackCreateMidiClip, this.handle, startTime, duration);
	}
};
//#endregion
//#region src/Scene.ts
/** Represents a scene. */
var Scene = class extends DataModelObject {
	static className = "Scene";
	get name() {
		return this.dataModel.sceneGetName(this.handle);
	}
	set name(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.sceneSetName(this.handle, value);
		});
	}
	get tempo() {
		return this.dataModel.sceneGetTempo(this.handle);
	}
	get signatureNumerator() {
		return this.dataModel.sceneGetSignatureNumerator(this.handle);
	}
	get signatureDenominator() {
		return this.dataModel.sceneGetSignatureDenominator(this.handle);
	}
};
//#endregion
//#region src/Song.ts
/** Represents the current Live Set. */
var Song = class extends DataModelObject {
	static className = "Song";
	/** Regular tracks only — excludes return tracks and the main track. */
	get tracks() {
		return this.dataModel.songGetTracks(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Track));
	}
	get returnTracks() {
		return this.dataModel.songGetReturnTracks(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Track));
	}
	get mainTrack() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.songGetMainTrack(this.handle), Track);
	}
	get scenes() {
		return this.dataModel.songGetScenes(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Scene));
	}
	get cuePoints() {
		return this.dataModel.songGetCuePoints(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, CuePoint));
	}
	get tempo() {
		return this.dataModel.songGetTempo(this.handle);
	}
	set tempo(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.songSetTempo(this.handle, value);
		});
	}
	/**
	* The current arrangement grid quantization. Use with {@link gridIsTriplet} to
	* determine the full grid setting.
	*/
	get gridQuantization() {
		return this.dataModel.songGetGridQuantization(this.handle);
	}
	/**
	* Whether the arrangement grid uses triplet subdivisions of the current
	* {@link gridQuantization} value.
	*/
	get gridIsTriplet() {
		return this.dataModel.songGetGridIsTriplet(this.handle);
	}
	/**
	* The root note of the scale currently selected in Live, as a MIDI note number
	* from 0 (C) to 11 (B).
	*/
	get rootNote() {
		return Number(this.dataModel.songGetRootNote(this.handle));
	}
	/** The name of the scale selected in Live, as shown in the Current Scale Name chooser. */
	get scaleName() {
		return this.dataModel.songGetScaleName(this.handle);
	}
	/** Whether Live's Scale Mode is enabled. */
	get scaleMode() {
		return this.dataModel.songGetScaleMode(this.handle);
	}
	/** The intervals of the current scale as semitone offsets from the root note. */
	get scaleIntervals() {
		return this.dataModel.songGetScaleIntervals(this.handle).map(Number);
	}
	/** Inserted after the last selected track, or appended if no track is selected. */
	createAudioTrack() {
		return createAsync(this.dataModel, this.objectRegistry, AudioTrack, this.dataModel.songCreateAudioTrack, this.handle);
	}
	/** Inserted after the last selected track, or appended if no track is selected. */
	createMidiTrack() {
		return createAsync(this.dataModel, this.objectRegistry, MidiTrack, this.dataModel.songCreateMidiTrack, this.handle);
	}
	/**
	* @param index - 0-based insert position in the range `[0, song.scenes.length]`.
	* Pass `-1` to append at the end.
	*/
	createScene(index) {
		return createAsync(this.dataModel, this.objectRegistry, Scene, this.dataModel.songCreateScene, this.handle, BigInt(index));
	}
	/**
	* Deletes a track from the song. Await the returned promise to ensure the
	* deletion has been fully processed.
	*/
	deleteTrack(track) {
		return invokeAsync(this.dataModel, this.dataModel.songDeleteTrack, this.handle, track.handle);
	}
	/**
	* Deletes a scene from the song. Await the returned promise to ensure the
	* deletion has been fully processed.
	*/
	deleteScene(scene) {
		return invokeAsync(this.dataModel, this.dataModel.songDeleteScene, this.handle, scene.handle);
	}
	/** Duplicates the track. The duplicate is inserted immediately after the original. */
	duplicateTrack(track) {
		return createAsync(this.dataModel, this.objectRegistry, Track, this.dataModel.songDuplicateTrack, this.handle, track.handle);
	}
	/** Duplicates the scene. The duplicate is inserted immediately after the original. */
	duplicateScene(scene) {
		return createAsync(this.dataModel, this.objectRegistry, Scene, this.dataModel.songDuplicateScene, this.handle, scene.handle);
	}
	/** @param time - Position in the arrangement in beats. */
	createCuePoint(time) {
		return createAsync(this.dataModel, this.objectRegistry, CuePoint, this.dataModel.songCreateCuePoint, this.handle, time);
	}
	/**
	* Deletes a cue point from the song. Await the returned promise to ensure
	* the deletion has been fully processed.
	*/
	deleteCuePoint(cuePoint) {
		return invokeAsync(this.dataModel, this.dataModel.songDeleteCuePoint, this.handle, cuePoint.handle);
	}
};
//#endregion
//#region src/Application.ts
/** Represents the application. */
var Application = class extends DataModelObject {
	static className = "Application";
	get song() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.rootGetSong(this.handle), Song);
	}
};
//#endregion
//#region src/Commands.ts
/**
* Registry for extension commands.
*
* Commands are identified by a string ID and can be invoked by Live (e.g. through a
* context menu action registered via {@link ExtensionContext.ui}) or programmatically
* via {@link Commands.executeCommand}.
*/
var Commands = class {
	module;
	/** @internal */
	constructor(module) {
		this.module = module;
	}
	/**
	* Registers a command that can be invoked by Live or via {@link Commands.executeCommand}.
	*
	* @param commandId - A unique string identifier for this command.
	* @param callback - Called when the command is invoked. May receive arguments passed by the invoker.
	*/
	registerCommand(commandId, callback) {
		this.module.registerCommand(commandId, callback);
	}
	/**
	* Programmatically invokes a registered command.
	*
	* @param commandId - The ID of the command to invoke.
	* @param args - Arguments to pass to the command's callback.
	*/
	executeCommand(commandId, ...args) {
		this.module.executeCommand(commandId, ...args);
	}
};
//#endregion
//#region src/ChainMixer.ts
/** Represents the mixer of a device chain. */
var ChainMixer = class extends DataModelObject {
	static className = "ChainMixerDevice";
	get volume() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.chainmixerdeviceGetVolume(this.handle), DeviceParameter);
	}
	get panning() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.chainmixerdeviceGetPanning(this.handle), DeviceParameter);
	}
	get sends() {
		return this.dataModel.chainmixerdeviceGetSends(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, DeviceParameter));
	}
};
//#endregion
//#region src/Chain.ts
/** Represents a device chain. */
var Chain = class extends DataModelObject {
	static className = "Chain";
	get devices() {
		return this.dataModel.chainGetDevices(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Device));
	}
	get mixer() {
		return this.objectRegistry.getObjectFromHandle(this.dataModel.chainGetMixerDevice(this.handle), ChainMixer);
	}
	/**
	* Inserts a built-in Live device with its default preset into the chain.
	* Only devices native to Live are supported — third-party plug-ins cannot be loaded this way.
	*
	* @param deviceName - The name of the built-in Live device (e.g. `"Reverb"`, `"Auto Filter"`).
	* @param index - Zero-based position in the device chain at which to insert.
	*/
	insertDevice(deviceName, index) {
		return createAsync(this.dataModel, this.objectRegistry, Device, this.dataModel.chainInsertDevice, this.handle, deviceName, BigInt(index));
	}
	/**
	* Deletes a device from this chain. Await the returned promise to ensure
	* the deletion has been fully processed.
	*/
	deleteDevice(device) {
		return invokeAsync(this.dataModel, this.dataModel.chainDeleteDevice, this.handle, device.handle);
	}
	/** The duplicate is inserted directly after the original in the device chain. */
	duplicateDevice(device) {
		return createAsync(this.dataModel, this.objectRegistry, Device, this.dataModel.chainDuplicateDevice, this.handle, device.handle);
	}
};
//#endregion
//#region src/DrumChain.ts
/** Represents a drum chain. */
var DrumChain = class extends Chain {
	static className = "DrumChain";
	get receivingNote() {
		return Number(this.dataModel.drumchainGetReceivingNote(this.handle));
	}
	set receivingNote(value) {
		this.dataModel.withinTransaction(() => {
			this.dataModel.drumchainSetReceivingNote(this.handle, BigInt(value));
		});
	}
};
//#endregion
//#region src/RackDevice.ts
/** Represents a rack device. */
var RackDevice = class extends Device {
	static className = "RackDevice";
	get chains() {
		return this.dataModel.rackdeviceGetChains(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, Chain));
	}
	/** @param index - 0-based insert position in the range `[0, rack.chains.length]`. */
	insertChain(index) {
		return createAsync(this.dataModel, this.objectRegistry, Chain, this.dataModel.rackdeviceInsertChain, this.handle, BigInt(index));
	}
};
//#endregion
//#region src/DrumRack.ts
/** Represents a Drum Rack device. */
var DrumRack = class extends RackDevice {
	static className = "DrumRackDevice";
	get chains() {
		return this.dataModel.rackdeviceGetChains(this.handle).map((handle) => this.objectRegistry.getObjectFromHandle(handle, DrumChain));
	}
};
//#endregion
//#region src/Sample.ts
/** Represents a sample. */
var Sample = class extends DataModelObject {
	static className = "Sample";
	get filePath() {
		return this.dataModel.sampleGetFilePath(this.handle);
	}
};
//#endregion
//#region src/Simpler.ts
/** Represents a Simpler device. */
var Simpler = class extends Device {
	static className = "Simpler";
	get sample() {
		const handle = this.dataModel.simplerGetSample(this.handle);
		return handle ? this.objectRegistry.getObjectFromHandle(handle, Sample) : null;
	}
	/** Replaces the loaded sample with the audio file at the given absolute path. */
	replaceSample(filePath) {
		return createAsync(this.dataModel, this.objectRegistry, Sample, this.dataModel.simplerReplaceSample, this.handle, filePath);
	}
};
//#endregion
//#region src/DataModelObjectRegistry.ts
const dataModelClasses = [
	Application,
	Song,
	AudioTrack,
	MidiTrack,
	Track,
	AudioClip,
	MidiClip,
	Clip,
	ClipSlot,
	TakeLane,
	Simpler,
	DrumRack,
	RackDevice,
	Device,
	Sample,
	DrumChain,
	Chain,
	Scene,
	CuePoint,
	DeviceParameter,
	TrackMixer,
	ChainMixer
];
/**
* Resolves {@link Handle}s into typed SDK objects.
*
* Objects are cached by handle ID, so the same Live object always returns the same SDK instance.
*/
var DataModelObjectRegistry = class {
	cache = /* @__PURE__ */ new Map();
	dataModel;
	/** @internal */
	constructor(dataModel) {
		this.dataModel = dataModel;
	}
	getOrCreateObjectFromHandle(handle) {
		const cached = this.cache.get(handle.id);
		if (cached) return cached;
		const ModelClass = dataModelClasses.find((cls) => this.dataModel.getObjectIsOfClass(handle, cls.className));
		if (!ModelClass) throw new Error("Unknown object type");
		const obj = new ModelClass(handle, this.dataModel, this);
		this.cache.set(handle.id, obj);
		return obj;
	}
	/**
	* Resolves a {@link Handle} into a typed SDK object.
	*
	* Pass {@link DataModelObject} as `type` when the exact type of the handle is not known
	* in advance, then use `instanceof` to branch on the actual type:
	*
	* ```ts
	* const obj = objects.getObjectFromHandle(handle, DataModelObject);
	* if (obj instanceof ClipSlot) {
	*   // ...
	* }
	* ```
	*
	* Throws if the underlying object has been deleted, if it is of a different
	* type than `type`, or if its type is not recognised.
	*
	* @param handle - The handle to resolve.
	* @param type - The expected SDK class (e.g. `ClipSlot`).
	*/
	getObjectFromHandle(handle, type) {
		const obj = this.getOrCreateObjectFromHandle(handle);
		if (!(obj instanceof type)) throw new Error("Object of incorrect type");
		return obj;
	}
};
//#endregion
//#region src/Environment.ts
/** Provides runtime environment information: filesystem paths and the current locale. */
var Environment = class {
	module;
	/** @internal */
	constructor(module) {
		this.module = module;
	}
	/**
	* Per-extension directory for persistent storage. Use it for configuration, credentials,
	* and cached state — anything that should survive across Live sessions.
	*/
	get storageDirectory() {
		return this.module.storageDirectory;
	}
	/**
	* Per-extension directory for temporary files, such as intermediate audio or analysis
	* results. May be cleaned up between sessions.
	*/
	get tempDirectory() {
		return this.module.tempDirectory;
	}
	/** Live's current UI language as an uppercase ISO 639-1 code (e.g. `"EN"`, `"DE"`, `"JA"`). */
	get language() {
		return this.module.language;
	}
};
//#endregion
//#region src/Resources.ts
/** Service for importing files into the Live project and rendering audio from the arrangement. */
var Resources = class {
	module;
	/** @internal */
	constructor(module) {
		this.module = module;
	}
	/**
	* Renders the pre-effects audio of a track in the arrangement between two beat
	* positions. Returns a path to a WAV file written to the extension's temp directory.
	*/
	renderPreFxAudio(track, startTime, endTime) {
		return new Promise((resolve, reject) => {
			this.module.renderPreFxAudio(track.handle, {
				endTime,
				startTime
			}, resolve, reject);
		});
	}
	/**
	* Copies a file into the Live project folder so that Live manages it.
	* Returns the path to the imported copy. Use the returned path in subsequent API
	* calls, not the original.
	*/
	importIntoProject(filePath) {
		return new Promise((resolve, reject) => {
			this.module.importIntoProject(filePath, resolve, reject);
		});
	}
};
//#endregion
//#region src/Ui.ts
const toProgressOptions = (text, progress) => typeof progress === "number" ? {
	progress,
	text
} : { text };
/** Service for UI interactions: context menus, modal dialogs, and progress dialogs. */
var Ui = class {
	module;
	/** @internal */
	constructor(module) {
		this.module = module;
	}
	/**
	* Registers a context menu action in the given {@link ContextMenuScope}.
	*
	* When the user triggers the action, Live invokes the command identified by
	* `commandId`. Depending on the scope, the command receives either the triggered
	* object's {@link Handle}, an {@link ArrangementSelection}, or a
	* {@link ClipSlotSelection} as its first argument.
	*
	* Returns a function that unregisters the action when called.
	*/
	registerContextMenuAction(scope, title, commandId) {
		return new Promise((resolve) => {
			this.module.registerContextMenuAction(scope, title, commandId, (unregister) => {
				resolve(() => new Promise((done) => {
					unregister(done);
				}));
			});
		});
	}
	/**
	* Opens a modal dialog that loads the given URL. Supported URL schemes are
	* `file:`, `data:`, `https:`, and `http://localhost`.
	*
	* To return a result and close the dialog, the dialog's HTML must post the message
	* `{ method: "close_and_send", params: [resultString] }` to the host's message
	* handler — `window.webkit.messageHandlers.live.postMessage` on macOS or
	* `window.chrome.webview.postMessage` on Windows. The returned promise resolves
	* with that string.
	*
	* Rejects if `url` is malformed or an unexpected error occurred.
	*/
	showModalDialog(url, width, height) {
		return new Promise((resolve, reject) => {
			this.module.showModalDialog(url, width, height, resolve, reject);
		});
	}
	/**
	* Shows a progress dialog while `callback` runs.
	* The callback receives an `update` function to change the text/progress
	* (progress is a percentage, 0–100), and an `AbortSignal` that fires if
	* the user cancels the dialog.
	* The dialog closes automatically when the callback resolves or rejects.
	*
	* @example
	* ```ts
	* const wavPath = await ui.withinProgressDialog(
	*   "Rendering audio…",
	*   { progress: 0 },
	*   async (update, signal) => {
	*     await update("Analysing…", 30);
	*     if (signal.aborted) return;
	*     await update("Rendering…", 70);
	*     return await resources.renderPreFxAudio(track, startBeat, endBeat);
	*   },
	* );
	* ```
	*/
	withinProgressDialog(text, options, callback) {
		const ac = new AbortController();
		return new Promise((resolve, reject) => {
			this.module.showProgressDialog(toProgressOptions(text, options.progress), ({ update, close }) => {
				const asyncUpdate = (updateText, progress) => new Promise((resolveUpdate) => {
					update(toProgressOptions(updateText, progress), resolveUpdate);
				});
				const asyncClose = () => new Promise((done) => {
					close(done);
				});
				callback(asyncUpdate, ac.signal).finally(asyncClose).then(resolve).catch(reject);
			}, () => {
				ac.abort();
			});
		});
	}
};
//#endregion
//#region src/Initialize.ts
/**
* Initializes the SDK with the Extension Host and returns the API context.
*
* Pass the lowest API version that covers all the features your extension needs.
* The Extension Host preserves older API versions as Live evolves, so targeting an
* older version keeps your extension compatible with a wider range of Live releases.
* Available versions are listed in {@link EXTENSIONS_API_VERSIONS}.
*
* Throws if the Extension Host does not support the requested API version.
*
* @param context - The activation context passed to your extension's `activate` function.
* @param apiVersion - The API version your extension targets (e.g. `"1.0.0"`).
* @returns An {@link ExtensionContext} providing access to Live's object model, commands, and UI.
*/
const initialize = (context, apiVersion) => {
	const { commands, dataModel, environment, resources, ui } = context.initializeExtensionHost({ apiVersion });
	const objectRegistry = new DataModelObjectRegistry(dataModel);
	return {
		application: objectRegistry.getObjectFromHandle(dataModel.getRoot(), Application),
		commands: new Commands(commands),
		environment: new Environment(environment),
		getObjectFromHandle: objectRegistry.getObjectFromHandle.bind(objectRegistry),
		resources: new Resources(resources),
		ui: new Ui(ui),
		withinTransaction: dataModel.withinTransaction.bind(dataModel)
	};
};
//#endregion
//#region src/ExtensionHost.ts
/**
* The size of the arrangement grid. Used with {@link Song.gridIsTriplet} to determine
* the full grid setting.
*/
let GridQuantization = /* @__PURE__ */ function(GridQuantization) {
	GridQuantization[GridQuantization["NoGrid"] = 0] = "NoGrid";
	GridQuantization[GridQuantization["EightBars"] = 1] = "EightBars";
	GridQuantization[GridQuantization["FourBars"] = 2] = "FourBars";
	GridQuantization[GridQuantization["TwoBars"] = 3] = "TwoBars";
	GridQuantization[GridQuantization["Bar"] = 4] = "Bar";
	GridQuantization[GridQuantization["Half"] = 5] = "Half";
	GridQuantization[GridQuantization["Quarter"] = 6] = "Quarter";
	GridQuantization[GridQuantization["Eighth"] = 7] = "Eighth";
	GridQuantization[GridQuantization["Sixteenth"] = 8] = "Sixteenth";
	GridQuantization[GridQuantization["ThirtySecond"] = 9] = "ThirtySecond";
	return GridQuantization;
}({});
/** Warp algorithm for an audio clip. Corresponds to Live's Warp Mode chooser. */
let WarpMode = /* @__PURE__ */ function(WarpMode) {
	WarpMode[WarpMode["Beats"] = 0] = "Beats";
	WarpMode[WarpMode["Tones"] = 1] = "Tones";
	WarpMode[WarpMode["Texture"] = 2] = "Texture";
	WarpMode[WarpMode["Repitch"] = 3] = "Repitch";
	WarpMode[WarpMode["Complex"] = 4] = "Complex";
	WarpMode[WarpMode["ComplexPro"] = 6] = "ComplexPro";
	return WarpMode;
}({});
/** All API versions supported by this SDK release, newest first. */
const EXTENSIONS_API_VERSIONS = ["1.0.0"];
//#endregion
exports.Application = Application;
exports.AudioClip = AudioClip;
exports.AudioTrack = AudioTrack;
exports.Chain = Chain;
exports.ChainMixer = ChainMixer;
exports.Clip = Clip;
exports.ClipSlot = ClipSlot;
exports.Commands = Commands;
exports.CuePoint = CuePoint;
exports.DataModelObject = DataModelObject;
exports.Device = Device;
exports.DeviceParameter = DeviceParameter;
exports.DrumChain = DrumChain;
exports.DrumRack = DrumRack;
exports.EXTENSIONS_API_VERSIONS = EXTENSIONS_API_VERSIONS;
exports.Environment = Environment;
exports.GridQuantization = GridQuantization;
exports.MidiClip = MidiClip;
exports.MidiTrack = MidiTrack;
exports.RackDevice = RackDevice;
exports.Resources = Resources;
exports.Sample = Sample;
exports.Scene = Scene;
exports.Simpler = Simpler;
exports.Song = Song;
exports.TakeLane = TakeLane;
exports.Track = Track;
exports.TrackMixer = TrackMixer;
exports.Ui = Ui;
exports.WarpMode = WarpMode;
exports.initialize = initialize;
