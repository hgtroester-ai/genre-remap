import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
test('2.1.0 embeds all ten MP3 samples and keeps the WebAudio decoder',()=>{
 for(const n of ['CRASH','RIDE','KICK','SNARE','RIM','LOWTOM','MIDTOM','HITOM','CLOSEDHAT','OPENHAT']) assert.ok(ui.includes(`const ${n}_SAMPLE_B64`));
 assert.match(ui,/decodeAudioData/); assert.match(ui,/Missing embedded MP3 drum sample/);
});
test('four velocity layers and calibrated playback remain intact',()=>{
 assert.match(ui,/return v<=50\?0:v<=80\?1:v<=105\?2:3/);
 assert.match(ui,/function playPreviewLayer\(when,buffer,lane,layer,velocity,mixGain\)/);
 assert.match(ui,/const PREVIEW_LAYER_GAIN=/); assert.match(ui,/function previewSegmentPeak\(/);
});
test('original, processed and compare preview modes remain available',()=>{
 for(const mode of ['processed','original','compare']) assert.ok(ui.includes('data-preview-mode="'+mode+'"'));
 assert.match(ui,/previewMode==='compare'/); assert.match(ui,/loopPreview/); assert.match(ui,/function stopPreview\(/);
});
test('source archive retains all ten original WAV masters',()=>{
 for(const n of ['crash','ride','kick','snare','rim','lowtom','midtom','hitom','closedhat','openhat']) assert.ok(fs.existsSync(new URL(`../assets/original-wav/${n}.wav`,import.meta.url)));
});
