import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');

test('Reggae family selector exposes One Drop as the default', () => {
  assert.match(source, /id="reggaeFamily"/);
  assert.match(source, /value="oneDrop" selected>One Drop/);
  assert.match(source, /value="rockers"/);
  assert.match(source, /value="steppers"/);
});

test('One Drop keeps kick and rim together on beat 3 with no default beat-1 kick', () => {
  assert.match(source, /const family=\$\('reggaeFamily'\)\?\.value\|\|SAVED\.reggaeFamily\|\|'oneDrop'/);
  assert.match(source, /out\.push\(\{pitch:36,time:base\+2/);
  assert.match(source, /out\.push\(\{pitch:37,time:base\+2/);
  assert.match(source, /if\(family==='rockers'\) out\.push\(\{pitch:36,time:base/);
});

test('Steppers generates quarter-note kick pulse; Rockers adds beat-1 kick', () => {
  assert.match(source, /for\(const beat of \[0,1,2,3\]\) out\.push\(\{pitch:36,time:base\+beat/);
  assert.match(source, /family==='rockers'\) out\.push\(\{pitch:36,time:base/);
});

test('Fill engine and Punk-specific logic remain present and untouched by family selector', () => {
  assert.match(source, /function applyFillEngine\(/);
  assert.match(source, /genre==='Punk'/);
  assert.match(source, /function punkFill|Punk.*fill|genre==='Punk'.*fill/s);
});

test('Version labels and package manifest are 1.9.2', () => {
  assert.match(source, /BUILD 2\.1\.0/);
  assert.doesNotMatch(source, /Version 1\.8\.4/);
  const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
  assert.equal(manifest.version, '2.1.0');
});
