import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
test('1.9.4 exposes the three Groove Dynamics controls with conservative defaults', () => {
  for (const id of ['ghostAmount','accentAmount','humanizeAmount']) assert.ok(source.includes(`'${id}'`), `missing ${id} control`);
  assert.match(source, /settings\.ghostAmount\?\?0/);
  assert.match(source, /settings\.accentAmount\?\?35/);
  assert.match(source, /settings\.humanizeAmount\?\?0/);
});
test('Groove Dynamics are used by processed preview, sequencer and Ableton clip export', () => {
  assert.match(source, /function applyGrooveDynamics\(input\)/);
  assert.match(source, /applyGrooveDynamics\(processed\.notes\)/);
  assert.match(source, /function getProcessedForView\(\).*?applyGrooveDynamics/s);
  assert.match(source, /mapFromCanonical\(applyGrooveDynamics\(transformed\.notes\)\)/);
});
test('Ghost notes are genre-aware and humanization stays within the documented timing bound', () => {
  assert.match(source, /\['Funk','Hip-Hop','Blues Rock'\]/);
  assert.match(source, /\(seed-\.5\)\*\.04\*human/);
  assert.match(source, /maximum timing shift is about 0\.02 beats/);
});
test('version metadata and UI label are synchronized at 1.9.4', () => {
  assert.match(source, /BUILD 2\.1\.0/);
  assert.equal(manifest.version, '2.1.0');
  assert.equal(pkg.version, '2.1.0');
});
