import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
test('1.9.11 exposes Natural, Balanced and Expressive velocity modes with sensitivity',()=>{
  for(const value of ['natural','balanced','expressive']) assert.ok(ui.includes(`value="${value}"`));
  assert.match(ui,/id="velocitySensitivity" type="range" min="0" max="150"/);
  assert.match(ui,/velocityMode:\$\('velocityMode'\)\.value/);
  assert.match(ui,/velocitySensitivity:Number\(\$\('velocitySensitivity'\)\.value\)/);
});
test('velocity profile preserves four original layer boundaries and adds bounded crossfades',()=>{
  assert.match(ui,/return v<=50\?0:v<=80\?1:v<=105\?2:3/);
  assert.match(ui,/bounds=\[50,80,105\],width=5/);
  assert.match(ui,/Math\.cos\(t\*Math\.PI\/2\)/);
  assert.match(ui,/Math\.sin\(t\*Math\.PI\/2\)/);
  assert.match(ui,/function playPreviewLayer\(/);
});
test('no fabricated round-robin sample variation is advertised',()=>{
  assert.match(ui,/no separate Round-Robin takes/);
  assert.doesNotMatch(ui,/Round.?Robin variation enabled/i);
});
test('legacy four-segment WAV playback, peak protection and mixer routing remain',()=>{
  assert.match(ui,/const PREVIEW_LAYER_GAIN=/);
  assert.match(ui,/function previewSegmentPeak\(/);
  assert.match(ui,/function mixerLaneAudible\(/);
  assert.match(ui,/function playPreviewSample\(when,name,velocity\).*previewLayerMix/s);
});
