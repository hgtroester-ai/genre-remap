import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const start=source.indexOf('function buildPhrase(');
const end=source.indexOf('function fillSettings()',start);
assert.ok(start>=0&&end>start,'Phrase Builder must exist');
const context={fillRole:n=>[35,36].includes(n.pitch)?'kick':[37,38,39,40].includes(n.pitch)?'snare':[42,44,46].includes(n.pitch)?'hat':[41,43,45,47,48,50].includes(n.pitch)?'tom':'other'};
vm.createContext(context);vm.runInContext(source.slice(start,end),context);
const buildPhrase=context.buildPhrase;
const PPQ=96;
const oneBar=[{pitch:36,time:0,duration:.1,velocity:100},{pitch:38,time:1,duration:.1,velocity:90},{pitch:42,time:.5,duration:.05,velocity:65},{pitch:42,time:1.5,duration:.05,velocity:65},{pitch:42,time:2.5,duration:.05,velocity:65},{pitch:42,time:3.5,duration:.05,velocity:65}];
test('one-bar groove expands to 4, 8 and 16 bars with notes in every bar',()=>{
 for(const bars of [4,8,16]){const r=buildPhrase(oneBar,1,bars,'funkster',PPQ);assert.equal(r.bars,bars);for(let b=0;b<bars;b++)assert.ok(r.notes.some(n=>n.time>=b*4&&n.time<(b+1)*4),`bar ${b+1} must contain groove notes`);}
});
test('original length is retained when target equals source length',()=>{const r=buildPhrase(oneBar,1,1,'pocket',PPQ);assert.deepEqual(JSON.parse(JSON.stringify(r.notes)),oneBar);});
test('phrase repetitions receive restrained drummer-profile dynamics and are deterministic',()=>{
 const a=buildPhrase(oneBar,1,8,'funkster',PPQ),b=buildPhrase(oneBar,1,8,'funkster',PPQ);assert.deepEqual(JSON.parse(JSON.stringify(a)),JSON.parse(JSON.stringify(b)));
 const v0=a.notes.filter(n=>n.time<4).map(n=>n.velocity),v1=a.notes.filter(n=>n.time>=4&&n.time<8).map(n=>n.velocity);assert.notDeepEqual(v0,v1,'repeated phrase bars should not be identical velocity copies');
});
test('phrase builder source is wired into preview and MIDI export and guarantees final fill',()=>{
 assert.match(source,/phraseBars>0 && !fillBars\.includes\(bars\)/);
 assert.match(source,/buildPhrase\(base,parsed\.bars,phraseBars,profile,parsed\.ppq\)/);
 assert.match(source,/phraseLength/);
});
