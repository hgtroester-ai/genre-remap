import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');

test('section 04 exposes exactly four remap intensity positions and five drummer feels', () => {
  assert.match(source, /id="remapLevel" type="range" min="1" max="4"[^>]*step="1"/);
  assert.match(source, /Level 1 · Light/);
  assert.match(source, /Level 2 · Moderate/);
  assert.match(source, /Level 3 · Strong/);
  assert.match(source, /Level 4 · Extreme/);
  for (const profile of ['pocket','powerhouse','funkster','machine','wildcard']) assert.match(source, new RegExp(`value="${profile}"`));
});

test('four levels map to distinct strengths and combine with selected drummer profile', () => {
  const block = source.slice(source.indexOf('const REMAP_LEVELS='), source.indexOf("$('remapLevel').value='2'"));
  assert.ok(block.includes("1:{mode:'subtle',strength:18"));
  assert.ok(block.includes("2:{mode:'balanced',strength:43"));
  assert.ok(block.includes("3:{mode:'bold',strength:72"));
  assert.ok(block.includes("4:{mode:'bold',strength:100"));
  assert.match(source, /applyDrummerFeel\(interpreted,\$\('drummerProfile'\)/);
});

test('English hover explanations are installed for controls and main panels', () => {
  assert.match(source, /const HOVER_HELP=/);
  for (const id of ['remapLevel','drummerProfile','fillFrequency','alternatingFills','endingFill','previewBtn','remap']) {
    assert.ok(source.includes(`${id}:`), `missing tooltip description for ${id}`);
  }
  assert.match(source, /applyHoverHelp\(\)/);
});

test('all visible version labels and package metadata are synchronized', () => {
  assert.match(source, /BUILD 2\.1\.0/);
  assert.doesNotMatch(source, /Version 1\.8\.4/);
  const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
  const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.equal(manifest.version, '2.1.0');
  assert.equal(pkg.version, '2.1.0');
});

test('1.8.4 initializes remap settings only after SAVED and parsed are declared', () => {
  const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
  const declaration = ui.indexOf('const GENRES=${genresJson}; const TRACKS=${tracksJson}; const SAVED=${saved};');
  const parsedDeclaration = ui.indexOf('let selectedFile=null, parsed=null, selectedGenre=SAVED.genre||\'Funk\';');
  const initialization = ui.indexOf("$('remapLevel').value=String(Math.max(1,Math.min(4,Number(SAVED.remapLevel??2))));syncRemapLevel();");
  assert.ok(declaration >= 0 && parsedDeclaration > declaration && initialization > parsedDeclaration, 'syncRemapLevel renders sequencer and must run after parsed leaves its temporal dead zone');
});

test('1.8.4 layout allows scrolling and keeps all section 04 controls accessible', () => {
  const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
  assert.match(ui, /#main\{display:flex!important;flex-direction:column!important;gap:9px!important;overflow:auto!important/);
  assert.match(ui, /#settingsCard .range-labels\{font-size:8px!important/);
  assert.match(ui, /\.range-labels\{display:grid;grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  for (const id of ['genreSelect','drummerProfile','fillFrequency','fillBar','fillDensity']) assert.ok(ui.includes('id="'+id+'"'), `${id} remains in UI`);
});

test('1.8.4 moves action controls below Target Genre in the sidebar and leaves four settings cards in bottomGrid', () => {
  const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
  const sidebar = ui.indexOf('<aside id=\"sidebar\">');
  const genreList = ui.indexOf('id=\"genreList\"', sidebar);
  const action = ui.indexOf('id=\"actionCard\"', sidebar);
  const main = ui.indexOf('<main id=\"main\"');
  const grid = ui.indexOf('<div id=\"bottomGrid\">', main);
  const gridEnd = ui.indexOf('</div>\n  </main>', grid);
  assert.ok(sidebar >= 0 && genreList > sidebar && action > genreList && action < main, 'Action card must follow Target Genre in the sidebar');
  assert.ok(grid > main && gridEnd > grid, 'bottomGrid must remain inside main');
  assert.equal((ui.slice(grid, gridEnd).match(/id=\"(?:destinationCard|settingsCard|fillEngineCard|grooveCard)\"/g)||[]).length, 4, 'only four settings cards remain in bottomGrid');
  assert.doesNotMatch(ui.slice(grid, gridEnd), /id=\"actionCard\"/);
  assert.match(ui, /#actionCard\.sidebar-action-card/);
  assert.match(ui, /#sidebar\{[^}]*overflow-y:auto!important/);
  assert.match(ui, /#bottomGrid\{grid-template-columns:minmax\(170px/);
});


test('1.9.1 groups variation controls in one framed horizontal panel', () => {
  const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
  assert.match(source, /<div class="variation-panel"><div class="variation-title">FILL VARIATION<\/div>/);
  assert.match(source, /#fillEngineCard>\.variation-panel\{[^}]*border:0!important/);
  assert.match(source, /#fillEngineCard\{height:auto!important/);
  assert.match(source, /class="variation-options"/);
  for (const id of ['variationStrength','variationMemory','dynamicVariation']) {
    assert.match(source, new RegExp('id="' + id + '"'));
  }
  assert.match(source, /grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
  assert.match(source, /BUILD 2\.1\.0/);
});


test('1.9.2 uses clearer Fill Variation labels and phrase-scoped repeat memory', () => {
  for (const label of ['Slight Changes','Varied','Strong Changes','Within Phrase','Across Song','Entire Clip','Consistent','Position-Based','Building Up']) assert.ok(source.includes(label), `missing label: ${label}`);
  assert.match(source, /phraseGroup/);
  assert.match(source, /usedPhraseVariants/);
  assert.match(source, /BUILD 2\.1\.0/);
});

test('1.9.3 Preview Studio exposes Original, Processed and Compare modes', () => {
  assert.match(source, /data-preview-mode="processed"/);
  assert.match(source, /data-preview-mode="original"/);
  assert.match(source, /data-preview-mode="compare"/);
  assert.match(source, /previewMode==='compare'\?\[\{notes:original\},\{notes:transformed\}\]/);
  assert.match(source, /mapFromCanonical\(applyGrooveDynamics\(processed\.notes\)\)/);
  assert.match(source, /mapFromCanonical\(applyVelocityControls\(mapToCanonical\(parsed\.notes\)\)\)/);
});
