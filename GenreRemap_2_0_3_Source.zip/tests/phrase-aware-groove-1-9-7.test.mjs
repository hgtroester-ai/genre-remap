import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const start=source.indexOf('function grooveRole(p)');
const end=source.indexOf('function remapNotes(',start);
assert.ok(start>=0&&end>start,'Phrase-aware groove engine must exist');
const code=source.slice(start,end);
function engine(){const c={};vm.createContext(c);vm.runInContext(code+';this.api={detectPhraseLength,applyPhraseAwareGroove};',c);return c.api;}
const notes=[];for(let bar=0;bar<8;bar++){notes.push({pitch:36,time:bar*4,duration:.1,velocity:100},{pitch:38,time:bar*4+1,duration:.1,velocity:90},{pitch:42,time:bar*4+.5,duration:.1,velocity:65},{pitch:42,time:bar*4+1.5,duration:.1,velocity:60},{pitch:46,time:bar*4+2.5,duration:.1,velocity:55});}
test('Automatic phrase detection selects sensible 4/8/16-bar cycles',()=>{const e=engine();assert.equal(e.detectPhraseLength(notes,'auto'),8);assert.equal(e.detectPhraseLength(notes.slice(0,16),'auto'),4);assert.equal(e.detectPhraseLength(notes.concat(notes.map(n=>({...n,time:n.time+32}))),'auto'),16);assert.equal(e.detectPhraseLength(notes,'4'),4);});
test('Stable mode preserves every note exactly',()=>{const out=engine().applyPhraseAwareGroove(notes,'Funk',480,'8','stable');assert.deepEqual(JSON.parse(JSON.stringify(out)),notes);});
test('Moderate and Evolving are deterministic and bounded',()=>{const e=engine();for(const mode of ['moderate','evolving']){const a=e.applyPhraseAwareGroove(notes,'Funk',480,'8',mode),b=e.applyPhraseAwareGroove(notes,'Funk',480,'8',mode);assert.deepEqual(JSON.parse(JSON.stringify(a)),JSON.parse(JSON.stringify(b)));assert.equal(a.length,notes.length);for(const n of a){assert.ok(Number.isFinite(n.time)&&n.time>=0);assert.ok(n.velocity>=1&&n.velocity<=127);}}});
test('Main kick and snare anchors remain unchanged',()=>{const out=engine().applyPhraseAwareGroove(notes,'Hip-Hop',480,'8','evolving');for(const n of notes.filter(n=>n.pitch===36||n.pitch===38)){const match=out.find(x=>x.pitch===n.pitch&&Math.abs(x.time-n.time)<1e-9);assert.ok(match,`anchor changed at ${n.time}`);}});
test('Phrase controls are wired into UI, settings and processed cache',()=>{assert.match(source,/id="phraseDevelopment"/);assert.match(source,/id="groovePhraseLength"/);assert.match(source,/applyPhraseAwareGroove\(filled\.notes/);assert.match(source,/phraseDevelopment:\$\('phraseDevelopment'\)/);});
