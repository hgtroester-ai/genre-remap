import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const start = source.indexOf('function fillSettings()');
const end = source.indexOf('function processedNotesWithFill()', start);
assert.ok(start >= 0 && end > start, 'Fill Engine functions must exist in src/ui.ts');
const context = {};
vm.createContext(context);
vm.runInContext(source.slice(start, end), context);
const applyFillEngine = context.applyFillEngine;

const groove = [];
for (let bar = 0; bar < 4; bar++) {
  for (const beat of [0, 2]) groove.push({ pitch: 36, time: bar * 4 + beat, duration: .12, velocity: 100 });
  for (const beat of [1, 3]) groove.push({ pitch: 38, time: bar * 4 + beat, duration: .12, velocity: 95 });
  for (let i = 0; i < 8; i++) groove.push({ pitch: 42, time: bar * 4 + i * .5, duration: .06, velocity: 65 });
}
const cfg = { enabled: true, length: 1, frequency: 'manual', bar: 4, style: 'genreDrummer', density: 55, landing: true };

test('disabled fill leaves source notes unchanged', () => {
  const result = applyFillEngine(groove, 'Funk', 'funkster',  PPQ, 4, { ...cfg, enabled: false });
  assert.deepEqual(JSON.parse(JSON.stringify(result.notes)), groove);
  assert.equal(result.bars, 4);
});

test('manual full-bar fill replaces the selected bar and lands on next bar 1', () => {
  const result = applyFillEngine(groove, 'Classic Rock', 'powerhouse',  PPQ, 4, cfg);
  assert.equal(result.bars, 5, 'clip extends to include next-bar landing');
  assert.ok(result.notes.some(n => n.pitch === 50 && n.time >= 12 && n.time < 16), 'fill includes high tom');
  assert.ok(result.notes.some(n => n.pitch === 45 && n.time >= 12 && n.time < 16), 'fill includes floor tom');
  assert.ok(result.notes.some(n => n.pitch === 36 && n.time === 16), 'kick landing on next bar 1');
  assert.ok(result.notes.some(n => n.pitch === 49 && n.time === 16), 'crash landing on next bar 1');
  assert.ok(!result.notes.some(n => n.pitch === 42 && n.time >= 12 && n.time < 16), 'normal hi-hat pulse is removed inside full-bar fill');
  assert.ok(result.notes.some(n => n.pitch === 42 && n.time < 12), 'earlier groove bars are preserved');
});

test('manual fill is deterministic for the same input and settings', () => {
  const a = applyFillEngine(groove, 'Funk', 'funkster', PPQ, 4, cfg);
  const b = applyFillEngine(groove, 'Funk', 'funkster', PPQ, 4, cfg);
  assert.deepEqual(JSON.parse(JSON.stringify(a)), JSON.parse(JSON.stringify(b)));
});

test('density changes the number of fill notes', () => {
  const sparse = applyFillEngine(groove, 'Punk', 'powerhouse', PPQ, 4, { ...cfg, density: 20 });
  const busy = applyFillEngine(groove, 'Punk', 'powerhouse', PPQ, 4, { ...cfg, density: 90 });
  const sparseHits = sparse.notes.filter(n => n.time >= 12 && n.time < 16 && [38, 45, 47, 50, 36].includes(n.pitch)).length;
  const busyHits = busy.notes.filter(n => n.time >= 12 && n.time < 16 && [38, 45, 47, 50, 36].includes(n.pitch)).length;
  assert.ok(busyHits > sparseHits, `expected busy fill (${busyHits}) to exceed sparse fill (${sparseHits})`);
});

test('short fill preserves the first half of the selected bar', () => {
  const result = applyFillEngine(groove, 'Alternative Rock', 'pocket', PPQ, 4, { ...cfg, length: .5, landing: false });
  assert.ok(result.notes.some(n => n.pitch === 42 && n.time >= 12 && n.time < 14), 'first two beats remain groove');
  assert.ok(!result.notes.some(n => n.pitch === 42 && n.time >= 14 && n.time < 16), 'last two beats are replaced by fill');
});

const PPQ = 960;

test('Punk genre fill uses a denser, tom-heavy sequence with rapid voice changes', () => {
  const result = applyFillEngine(groove, 'Punk', 'powerhouse', PPQ, 4, cfg);
  const fillNotes = result.notes.filter(n => n.time >= 12 && n.time < 16);
  const toms = fillNotes.filter(n => [45, 47, 50].includes(n.pitch));
  const tomPitches = new Set(toms.map(n => n.pitch));
  assert.ok(toms.length >= 4, `expected tom-heavy Punk fill, got ${toms.length} tom hits`);
  assert.ok(tomPitches.size >= 3, `expected all three tom voices, got ${[...tomPitches].join(', ')}`);
  assert.ok(fillNotes.some(n => [38, 45, 47, 50].includes(n.pitch)), 'Punk fill contains snare/tom strokes');
  assert.ok(fillNotes.some(n => Math.abs(n.time * 4 - Math.round(n.time * 4)) < 1e-6), 'fill aligns to straight 16th grid');
});

test('Reggae genre fills use restrained, drummer-specific patterns', () => {
  const pocket = applyFillEngine(groove, 'Reggae', 'pocket', PPQ, 4, cfg);
  const machine = applyFillEngine(groove, 'Reggae', 'machine', PPQ, 4, cfg);
  const funkster = applyFillEngine(groove, 'Reggae', 'funkster', PPQ, 4, cfg);
  const fill = notes => notes.filter(n => n.time >= 12 && n.time < 16);
  const pitches = notes => fill(notes).map(n => `${n.pitch}@${Math.round(n.time*16)/16}`).join('|');
  assert.ok(fill(pocket.notes).some(n => n.pitch === 37), 'Reggae fill includes rim/cross-stick notes');
  assert.ok(fill(pocket.notes).some(n => [45,47,50].includes(n.pitch)), 'Reggae fill includes short tom answers');
  assert.notEqual(pitches(pocket.notes), pitches(machine.notes), 'Pocket and Machine use different Reggae fill contours');
  assert.notEqual(pitches(machine.notes), pitches(funkster.notes), 'Machine and Funkster use different Reggae fill contours');
});

test('intelligent generator creates distinct Funk fills across an 8-bar phrase', () => {
  const longGroove=[];
  for(let bar=0;bar<8;bar++) for(let i=0;i<4;i++) longGroove.push({pitch:i%2?38:36,time:bar*4+i,duration:.1,velocity:90});
  const result=applyFillEngine(longGroove,'Funk','funkster',PPQ,8,{...cfg,frequency:'4',landing:false,generatorMode:'intelligent',density:75});
  const fillSignature=bar=>result.notes.filter(n=>n.time>=(bar-1)*4&&n.time<bar*4&&[36,38,45,47,50].includes(n.pitch)).map(n=>`${n.pitch}@${Math.round((n.time-(bar-1)*4)*16)/16}`).join('|');
  assert.notEqual(fillSignature(4),fillSignature(8),'Funk fills in bars 4 and 8 must differ in rhythm and/or voice');
});

test('intelligent generator is deterministic and preserves the Punk legacy branch', () => {
  const a=applyFillEngine(groove,'Classic Rock','powerhouse',PPQ,4,{...cfg,generatorMode:'intelligent',landing:false});
  const b=applyFillEngine(groove,'Classic Rock','powerhouse',PPQ,4,{...cfg,generatorMode:'intelligent',landing:false});
  assert.deepEqual(JSON.parse(JSON.stringify(a)),JSON.parse(JSON.stringify(b)));
  const punkA=applyFillEngine(groove,'Punk','powerhouse',PPQ,4,{...cfg,generatorMode:'intelligent',landing:false});
  const punkB=applyFillEngine(groove,'Punk','powerhouse',PPQ,4,{...cfg,generatorMode:'classic',landing:false});
  assert.deepEqual(JSON.parse(JSON.stringify(punkA)),JSON.parse(JSON.stringify(punkB)),'Punk must bypass the new generator');
});

test('intelligent generator varies all four Funk fills in a 16-bar song', () => {
  const longGroove=[];
  for(let bar=0;bar<16;bar++) for(let i=0;i<8;i++) longGroove.push({pitch:[36,38,42][i%3],time:bar*4+i*.5,duration:.08,velocity:80+i});
  const result=applyFillEngine(longGroove,'Funk','funkster',PPQ,16,{...cfg,frequency:'4',landing:false,generatorMode:'intelligent',density:65});
  const signatures=[4,8,12,16].map(bar=>result.notes.filter(n=>n.time>=(bar-1)*4&&n.time<bar*4&&[36,38,45,47,50].includes(n.pitch)).map(n=>`${n.pitch}@${Math.round((n.time-(bar-1)*4)*16)/16}`).join('|'));
  assert.equal(new Set(signatures).size,4,'all four fills must have distinct note/time structures');
});

test('intelligent generator provides more than eight distinct fill structures in a long Funk phrase',()=>{
 const long=[];for(let bar=0;bar<64;bar++){for(let i=0;i<4;i++)long.push({pitch:i%2?38:36,time:bar*4+i,duration:.1,velocity:90});}
 const result=applyFillEngine(long,'Funk','funkster',PPQ,64,{...cfg,frequency:'4',endingFill:false,landing:false,generatorMode:'intelligent',density:70,variantCount:16});
 const signature=bar=>result.notes.filter(n=>n.time>=(bar-1)*4&&n.time<bar*4&&[36,38,45,47,49,50].includes(n.pitch)).map(n=>`${n.pitch}@${Math.round((n.time-(bar-1)*4)*16)/16}`).join('|');
 const signatures=Array.from({length:16},(_,i)=>signature((i+1)*4));
 assert.ok(new Set(signatures).size>8,'16-bar cycles should expose more than eight distinct fill patterns');
});

test('intelligent Funk fill voice contour changes with Drummer Feel',()=>{
 const pocket=applyFillEngine(groove,'Funk','pocket',PPQ,8,{...cfg,frequency:'4',endingFill:false,landing:false,generatorMode:'intelligent'});
 const powerhouse=applyFillEngine(groove,'Funk','powerhouse',PPQ,8,{...cfg,frequency:'4',endingFill:false,landing:false,generatorMode:'intelligent'});
 const sig=r=>r.notes.filter(n=>n.time>=12&&n.time<16&&[36,38,45,47,49,50].includes(n.pitch)).map(n=>`${n.pitch}@${Math.round(n.time*PPQ)}`).sort().join('|');
 assert.notEqual(sig(pocket),sig(powerhouse),'Drummer Feel should affect instrument contour, not only velocity');
});

test('Phrase Builder guarantees a final fill even when Manual bar placement is selected',()=>{
 const result=applyFillEngine(groove,'Funk','funkster',PPQ,4,{...cfg,frequency:'manual',bar:2,phraseBars:4,endingFill:false,landing:true,generatorMode:'intelligent'});
 assert.ok(result.notes.some(n=>n.time>=12&&n.time<16&&[36,38,45,47,49,50].includes(n.pitch)),'last phrase bar must contain a fill');
 assert.equal(result.bars,4,'final phrase fill must not create an extra landing bar');
});


test('Fill Style Variation Manager changes consecutive fills for Linear, Tom Run, Snare Roll and Triplet styles',()=>{
  const longGroove=Array.from({length:2},(_,copy)=>groove.map(n=>({...n,time:n.time+copy*16}))).flat();
  const sig=(notes,bar)=>notes.filter(n=>n.time>=(bar-1)*4&&n.time<bar*4).map(n=>`${n.pitch}@${Math.round(n.time*PPQ)}`).sort().join('|');
  for (const style of ['linear','tomRun','snareRoll','triplet']) {
    const result=applyFillEngine(longGroove,'Funk','funkster',PPQ,8,{...cfg,style,frequency:'4',endingFill:false,landing:false,alternating:true,variationStrength:'balanced',variationMemory:'song',dynamicVariation:'progressive'});
    const a=sig(result.notes,4),b=sig(result.notes,8);
    assert.notEqual(a,b,`${style} must produce different note/time patterns at bars 4 and 8`);
  }
});

test('1.8.3 exposes Fill Engine as its own column and uses requested manager defaults',()=>{
  assert.match(source,/id="fillEngineCard"/);
  assert.match(source,/id="variationStrength"[\s\S]*?value="balanced" selected/);
  assert.match(source,/id="variationMemory"[\s\S]*?value="song" selected/);
  assert.match(source,/id="dynamicVariation"[\s\S]*?value="progressive" selected/);
  assert.match(source,/#bottomGrid\{display:grid!important;grid-template-columns:minmax\(175px/);
  assert.doesNotMatch(source,/Independent MIDI extension<br>Version 1\.8\.3/);
});


test('Phrase memory resets repeat avoidance at phrase boundaries in both fill generators',()=>{
  assert.match(source,/phraseGroup/);
  assert.match(source,/usedPhraseVariants/);
  assert.ok(source.includes("variationMemory==='phrase'?usedPhraseVariants:usedSongVariants"));
});
