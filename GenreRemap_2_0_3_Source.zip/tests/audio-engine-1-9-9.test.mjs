import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const ext=fs.readFileSync(new URL('../src/extension.ts',import.meta.url),'utf8');
test('2.1.0 embeds ten high-quality MP3 preview assets and retains WAV masters in source',()=>{
  for(const n of ['CRASH','RIDE','KICK','SNARE','RIM','LOWTOM','MIDTOM','HITOM','CLOSEDHAT','OPENHAT']) assert.ok(ui.includes(n+'_SAMPLE_B64'));
  assert.match(ui,/SUQzBA|\/\/\/\/|\/\+\/\/|AAAA/); assert.match(ui,/Missing embedded MP3 drum sample/);
});
test('MP3 preview selects one of four velocity layers and starts within that segment',()=>{
  assert.match(ui,/function previewVelocityLayer\(velocity\)/);
  assert.match(ui,/return v<=50\?0:v<=80\?1:v<=105\?2:3/);
  assert.match(ui,/function playPreviewLayer\(when,buffer,lane,layer,velocity,mixGain\)/);
  assert.match(ui,/src\.start\(when,offset,Math\.max\(\.04,segment-\.012\)\)/);
});
test('MP3 preview uses layer calibration, peak protection, stereo lanes and compressor',()=>{
  assert.match(ui,/const PREVIEW_LAYER_GAIN=/);
  assert.match(ui,/function previewSegmentPeak\(/);
  assert.match(ui,/const PREVIEW_LANE_PAN=/);
  assert.match(ui,/createStereoPanner/);
  assert.match(ui,/createDynamicsCompressor/);
});
test('Original / Processed / Compare, loop and stop paths remain connected',()=>{
  for(const mode of ['processed','original','compare']) assert.ok(ui.includes('data-preview-mode="'+mode+'"'));
  assert.match(ui,/previewMode==='compare'/); assert.match(ui,/loopPreview/); assert.match(ui,/function stopPreview\(/);
});
