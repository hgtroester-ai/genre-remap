import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const start = source.indexOf('function fillSettings()');
const end = source.indexOf('function processedNotesWithFill()', start);
assert.ok(start >= 0 && end > start, 'Fill Engine functions must exist');
const context = {};
vm.createContext(context);
vm.runInContext(source.slice(start, end), context);
const applyFillEngine = context.applyFillEngine;
const PPQ = 960;
function groove(bars) {
  const notes=[];
  for(let bar=0;bar<bars;bar++) {
    notes.push({pitch:36,time:bar*4,duration:.12,velocity:100});
    notes.push({pitch:38,time:bar*4+1,duration:.12,velocity:95});
    notes.push({pitch:38,time:bar*4+3,duration:.12,velocity:95});
    for(let i=0;i<8;i++) notes.push({pitch:42,time:bar*4+i*.5,duration:.06,velocity:65});
  }
  return notes;
}
const cfg={enabled:true,length:1,frequency:'8',bar:4,style:'genreDrummer',density:75,landing:false,alternating:true,endingFill:true,variantCount:8};
const fillSignature=(notes,bar)=>notes.filter(n=>n.time>=(bar-1)*4&&n.time<bar*4).map(n=>`${n.pitch}@${Math.round(n.time*PPQ)}`).sort().join('|');

test('eight alternating fills produce distinct note/time patterns, not velocity-only changes',()=>{
  const result=applyFillEngine(groove(64),'Classic Rock','pocket',PPQ,64,cfg);
  const signatures=[8,16,24,32,40,48,56,64].map(bar=>fillSignature(result.notes,bar));
  assert.equal(new Set(signatures).size,8,`expected 8 unique patterns, got ${new Set(signatures).size}`);
  assert.ok(signatures.every(Boolean),'each interval should contain a fill');
});

test('own ending fill is added when song length is not an interval multiple',()=>{
  const result=applyFillEngine(groove(10),'Classic Rock','pocket',PPQ,10,cfg);
  assert.ok(result.notes.some(n=>n.time>=36&&n.time<40&&[38,45,47,50].includes(n.pitch)),'bar 10 contains ending fill notes');
  assert.equal(result.bars,10,'no extra bar is added when landing is disabled');
});

test('Punk fill note pattern remains unchanged when alternation is toggled',()=>{
  const notes=groove(16);
  const a=applyFillEngine(notes,'Punk','powerhouse',PPQ,16,{...cfg,alternating:false,endingFill:false});
  const b=applyFillEngine(notes,'Punk','powerhouse',PPQ,16,{...cfg,alternating:true,endingFill:false});
  assert.deepEqual(JSON.parse(JSON.stringify(a)),JSON.parse(JSON.stringify(b)));
});

test('version labels and package manifest are synchronized to 1.9.5',()=>{
  assert.match(source,/BUILD 2\.1\.0/);
  assert.doesNotMatch(source,/Version 1\.8\.4/);
  const manifest=JSON.parse(fs.readFileSync(new URL('../manifest.json',import.meta.url),'utf8'));
  assert.equal(manifest.version,'2.1.0');
});

test('the eighth bar contains the interval fill; final ending fill does not create a ninth bar',()=>{
  const result=applyFillEngine(groove(8),'Classic Rock','pocket',PPQ,8,{...cfg,landing:true,endingFill:true});
  assert.ok(result.notes.some(n=>n.time>=28&&n.time<32&&[38,45,47,50].includes(n.pitch)),'fill notes must be placed inside bar 8');
  assert.equal(result.bars,8,'final ending fill must not extend an 8-bar song to 9 bars');
  assert.ok(!result.notes.some(n=>n.time>=32&&n.time<36),'no landing notes should be added after the final bar');
});

test('non-final interval fills still receive their next-bar landing',()=>{
  const result=applyFillEngine(groove(16),'Classic Rock','pocket',PPQ,16,{...cfg,landing:true,endingFill:false});
  assert.ok(result.notes.some(n=>n.pitch===36&&n.time===32),'bar 8 fill should land on bar 9 beat 1 when not at song end');
  assert.equal(result.bars,17,'non-final landing extends clip when required');
});

test('MIDI bar count uses the last note onset so a tiny boundary overrun does not create bar 9',()=>{
  const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
  assert.match(ui,/const lastNoteOnTick=Math\.max\(\.\.\.notes\.map\(n=>n\.tick\)\)/);
  assert.match(ui,/bars:Math\.max\(1,Math\.ceil\(\(lastNoteOnTick\+1\)\/\(ppq\*4\)\)\)/);
  const ppq=96, barTicks=ppq*4, lastNoteOnTick=3051, lastNoteEndTick=3075;
  assert.ok(lastNoteEndTick>barTicks*8,'uploaded source MIDI has a 3-tick note tail beyond bar 8');
  assert.equal(Math.ceil((lastNoteOnTick+1)/barTicks),8,'source phrase remains 8 bars based on note onset');
  assert.equal(Math.ceil(lastNoteEndTick/barTicks),9,'old end-time rounding would incorrectly create bar 9');
  assert.doesNotMatch(ui,/bars:Math\.max\(1,Math\.ceil\(musicalEndTick\/\(ppq\*4\)\)\)/);
});


test('Fill Variation Manager keeps every interval fill distinct in an 8-bar and 16-bar song',()=>{
  for (const bars of [8,16]) {
    const result=applyFillEngine(groove(bars),'Funk','funkster',PPQ,bars,{...cfg,frequency:'4',endingFill:false,landing:false});
    const fillBars=Array.from({length:Math.floor(bars/4)},(_,i)=>(i+1)*4);
    const signatures=fillBars.map(bar=>fillSignature(result.notes,bar));
    assert.equal(new Set(signatures).size,signatures.length,`${bars}-bar song should not repeat interval fill patterns`);
  }
});


test('Funk fills change their actual voice contours between bar 4 and bar 8',()=>{
  const result=applyFillEngine(groove(8),'Funk','funkster',PPQ,8,{...cfg,frequency:'4',endingFill:false,landing:false});
  const signature=(bar)=>result.notes.filter(n=>n.time>=(bar-1)*4&&n.time<bar*4&&[36,38,45,47,50].includes(n.pitch)).map(n=>`${n.pitch}@${Math.round(n.time*PPQ)}`).sort().join('|');
  assert.notEqual(signature(4),signature(8),'Funk fill patterns must differ in actual note/time content');
});

test('Ska fill patterns vary in both rhythm and drum voice',()=>{
  const result=applyFillEngine(groove(16),'Ska','powerhouse',PPQ,16,{...cfg,frequency:'4',endingFill:false,landing:false});
  const signature=(bar)=>result.notes.filter(n=>n.time>=(bar-1)*4&&n.time<bar*4&&[36,38,45,47,50].includes(n.pitch)).map(n=>`${n.pitch}@${Math.round(n.time*PPQ)}`).sort().join('|');
  const signatures=[4,8,12,16].map(signature);
  assert.equal(new Set(signatures).size,4,'each Ska fill should have a distinct pattern');
});

test('final interval fill is a normal variation, not a forced special ending pattern',()=>{
  const a=applyFillEngine(groove(16),'Classic Rock','pocket',PPQ,16,{...cfg,frequency:'4',endingFill:true,landing:false});
  const b=applyFillEngine(groove(16),'Classic Rock','pocket',PPQ,16,{...cfg,frequency:'4',endingFill:false,landing:false});
  assert.equal(fillSignature(a.notes,16),fillSignature(b.notes,16));
});


test('16 requested variants never index beyond the eight available alternating maps',()=>{
  const result=applyFillEngine(groove(64),'Classic Rock','pocket',PPQ,64,{...cfg,frequency:'4',endingFill:false,landing:false,variantCount:16});
  assert.ok(result.notes.length>0,'processing completes and returns MIDI notes');
  assert.ok(result.notes.every(n=>Number.isFinite(n.time)&&Number.isFinite(n.pitch)),'all generated notes remain valid');
});
