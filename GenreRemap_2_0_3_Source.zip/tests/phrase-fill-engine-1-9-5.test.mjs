import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const start=source.indexOf('function fillSettings()');
const end=source.indexOf('function processedNotesWithFill()',start);
const context={};vm.createContext(context);vm.runInContext(source.slice(start,end),context);
const applyFillEngine=context.applyFillEngine;const PPQ=960;

test('phrase-end fill frequency places fills at every selected phrase boundary',()=>{
 const groove=[];for(let bar=0;bar<16;bar++){groove.push({pitch:36,time:bar*4,duration:.1,velocity:100},{pitch:38,time:bar*4+1,duration:.1,velocity:90});for(let i=0;i<8;i++)groove.push({pitch:42,time:bar*4+i*.5,duration:.05,velocity:65});}
 const result=applyFillEngine(groove,'Funk','funkster',PPQ,16,{enabled:true,length:1,frequency:'phrase',bar:4,style:'genreDrummer',density:65,landing:false,alternating:true,endingFill:false,variantCount:16,generatorMode:'intelligent',phraseBars:4,variationMemory:'phrase'});
 for(const bar of [4,8,12,16])assert.ok(result.notes.some(n=>n.time>=(bar-1)*4&&n.time<bar*4&&[38,45,47,50].includes(n.pitch)),`phrase ${bar} should end with a fill`);
 assert.ok(result.notes.some(n=>n.pitch===38&&Math.abs(n.time-11.5)<.001),'a quiet snare pickup prepares the first phrase-ending fill');
 assert.ok(result.notes.some(n=>n.pitch===38&&Math.abs(n.time-27.5)<.001),'pickup repeats before the second phrase-ending fill');
});

test('phrase-end fills default to four bars when Phrase Builder remains at original length',()=>{
 const groove=[];for(let bar=0;bar<8;bar++)groove.push({pitch:36,time:bar*4,duration:.1,velocity:100},{pitch:38,time:bar*4+1,duration:.1,velocity:90});
 const result=applyFillEngine(groove,'Reggae','pocket',PPQ,8,{enabled:true,length:1,frequency:'phrase',bar:4,style:'genreDrummer',density:55,landing:false,alternating:true,endingFill:false,phraseBars:0});
 assert.ok(result.notes.some(n=>n.time>=12&&n.time<16&&[37,38,45,47,50].includes(n.pitch)),'bar 4 receives a phrase fill');
 assert.ok(result.notes.some(n=>n.time>=28&&n.time<32&&[37,38,45,47,50].includes(n.pitch)),'bar 8 receives a phrase fill');
 assert.ok(result.notes.some(n=>n.pitch===37&&Math.abs(n.time-11.5)<.001),'Reggae uses rim/cross-stick as the phrase pickup');
});
