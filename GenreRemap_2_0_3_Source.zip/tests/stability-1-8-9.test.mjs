import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const ext=fs.readFileSync(new URL('../src/extension.ts',import.meta.url),'utf8');

test('sequencer redraws are coalesced to one animation frame',()=>{
  assert.match(ui,/let sequencerFrame=0;function renderSequencer\(\)\{if\(sequencerFrame\)return;/);
  assert.match(ui,/function renderSequencerNow\(\)/);
});
test('processed MIDI transform is memoized by source and all transformation settings',()=>{
  assert.match(ui,/let processedCache=\{source:null,key:'',value:null\}/);
  assert.match(ui,/processedCache\.source===parsed&&processedCache\.key===key&&processedCache\.value/);
  assert.match(ui,/processedCache=\{source:parsed,key,value\}/);
  assert.match(ui,/processedCache=\{source:null,key:'',value:null\}/);
});
test('preview initialization can recover after a failed sample decode',()=>{
  assert.match(ui,/previewLoading=null;for\(const key of Object\.keys\(previewBuffers\)\)delete previewBuffers\[key\]/);
  assert.match(ui,/if\(!AudioCtor\)throw new Error\('Web Audio API is not available/);
  assert.match(ui,/const all=groups\.flatMap\(g=>g\.notes\),audible=all\.filter\(n=>sampleName\(n\.pitch\)&&previewBuffers\[sampleName\(n\.pitch\)\]\)/);
});
test('remix button uses the same processed result as the sequencer and checks host transport',()=>{
  assert.match(ui,/const transformed=processedNotesWithFill\(\)/);
  assert.match(ui,/if\(!closeWith\(payload\)\)/);
  assert.match(ui,/Sending '\+notes\.length\+' MIDI notes to Ableton Live/);
});
test('Ableton context-menu ClipSlot handle is primary and window selection is fallback',()=>{
  assert.match(ext,/let target:ClipSlot<'1\.0\.0'>\|null=fallback/);
  assert.ok(ext.indexOf('let target:ClipSlot') < ext.indexOf('if(!target&&msg.trackIndex!==undefined'));
});
test('clip creation, MIDI assignment and naming stay inside one transaction',()=>{
  const start=ext.indexOf('try{await context.withinTransaction');
  const end=ext.indexOf('}catch(e){const detail',start);
  const transaction=ext.slice(start,end);
  assert.match(transaction,/const clip=await slot\.createMidiClip\(bars\*4\)/);
  assert.match(transaction,/clip\.notes=notes/);
  assert.match(transaction,/clip\.name=/);
  assert.match(ext,/Details: '\+detail/);
});
test('preview resumes AudioContext from the click path before waiting for sample decoding',()=>{
  assert.match(ui,/const loading=initPreview\(\);const c=previewContext;if\(!c\)throw new Error\('AudioContext could not be created\.'\);await c\.resume\(\);await loading/);
});
test('embedded preview samples include all ten expected MP3 instruments',()=>{
  for(const name of ['CRASH','RIDE','KICK','SNARE','RIM','LOWTOM','MIDTOM','HITOM','CLOSEDHAT','OPENHAT']) {
    assert.match(ui,new RegExp('const '+name+'_SAMPLE_B64 ='));
  }
  assert.ok(ui.includes('SUQzBA'),'embedded sample data has an ID3/MP3 header');
});
