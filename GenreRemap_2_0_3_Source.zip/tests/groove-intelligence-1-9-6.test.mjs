import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const start=source.indexOf('function grooveRole(p)');
const end=source.indexOf('function buildPhrase(',start);
assert.ok(start>=0 && end>start,'Groove Intelligence implementation must exist');
const code=source.slice(start,end);
function engine(settings={},tempo=120){
 const context={parsed:{tempo},SAVED:{},$(id){return {value:settings[id]??({timingFeel:'auto',grooveAmount:100,swingAmount:100,preserveOriginalGroove:'low'}[id])};}};
 vm.createContext(context);vm.runInContext(code+';this.api={analyseSourceGroove,applyGenreGrooveIntelligence};',context);return context.api;
}
const src=[{pitch:36,time:0,duration:.1,velocity:100},{pitch:38,time:1.02,duration:.1,velocity:90},{pitch:42,time:.52,duration:.1,velocity:70},{pitch:42,time:1.52,duration:.1,velocity:65},{pitch:36,time:2,duration:.1,velocity:100},{pitch:38,time:3.02,duration:.1,velocity:90}];
const target=[{pitch:36,time:0,duration:.1,velocity:100},{pitch:38,time:1,duration:.1,velocity:90},{pitch:42,time:.5,duration:.1,velocity:70},{pitch:42,time:1.5,duration:.1,velocity:65}];
test('Auto is deterministic and returns finite, bounded note times',()=>{const e=engine();const a=e.applyGenreGrooveIntelligence(src,target,'Funk',480);const b=e.applyGenreGrooveIntelligence(src,target,'Funk',480);assert.deepEqual(JSON.parse(JSON.stringify(a)),JSON.parse(JSON.stringify(b)));for(const n of a){assert.ok(Number.isFinite(n.time));assert.ok(n.time>=0);assert.ok(Math.abs(n.time-target.find(x=>x.pitch===n.pitch&&Math.abs(x.time-n.time)<.1)?.time??0)<.2);}});
test('High preservation keeps source timing closer than Low',()=>{const high=engine({timingFeel:'auto',grooveAmount:100,swingAmount:100,preserveOriginalGroove:'high'}).applyGenreGrooveIntelligence(src,target,'Hip-Hop',480);const low=engine({timingFeel:'auto',grooveAmount:100,swingAmount:100,preserveOriginalGroove:'low'}).applyGenreGrooveIntelligence(src,target,'Hip-Hop',480);assert.ok(Math.abs(high[1].time-1.02)<=Math.abs(low[1].time-1.02)+1e-9);});
test('Genre profiles produce distinct timing for the snare',()=>{const punk=engine({timingFeel:'auto',grooveAmount:100,preserveOriginalGroove:'low'}).applyGenreGrooveIntelligence(src,target,'Punk',480);const hip=engine({timingFeel:'auto',grooveAmount:100,preserveOriginalGroove:'low'}).applyGenreGrooveIntelligence(src,target,'Hip-Hop',480);assert.notEqual(punk[1].time,hip[1].time);});
test('Straight feel suppresses swing displacement',()=>{const straight=engine({timingFeel:'straight',grooveAmount:100,swingAmount:100,preserveOriginalGroove:'low'}).applyGenreGrooveIntelligence(src,target,'Blues Rock',480);const hat=straight.find(n=>n.pitch===42);assert.ok(Math.abs(hat.time-.5)<.03);});
test('Empty source and empty target are safe',()=>{const e=engine();assert.deepEqual(JSON.parse(JSON.stringify(e.applyGenreGrooveIntelligence([],target,'Funk',480))),JSON.parse(JSON.stringify(target)));assert.deepEqual(e.applyGenreGrooveIntelligence(src,[],'Funk',480),[]);});
