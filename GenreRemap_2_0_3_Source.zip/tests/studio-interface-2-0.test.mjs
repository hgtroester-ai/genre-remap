import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const manifest=JSON.parse(fs.readFileSync(new URL('../manifest.json',import.meta.url)));
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url)));
test('2.1.0 Studio Interface exposes three accessible settings tabs',()=>{
 assert.equal(manifest.version,'2.1.0'); assert.equal(pkg.version,'2.1.0'); assert.match(ui,/BUILD 2\.1\.0/);
 for(const tab of ['remap','groove','audio']) assert.match(ui,new RegExp(`data-studio-tab="${tab}"`));
 assert.match(ui,/role="tablist"/); assert.match(ui,/role="tabpanel"/);
});
test('2.1.0 keeps existing controls and moves them into the intended Studio groups',()=>{
 for(const id of ['destinationCard','settingsCard','fillEngineCard','grooveCard','previewMixerPanel','velocityMode','velocitySensitivity','previewVolume','targetTempo','loopPreview','applyLiveTempo']) assert.ok(ui.includes(`'${id}'`)||ui.includes(`id="${id}"`),`missing ${id}`);
 assert.match(ui,/\['destinationCard','settingsCard','fillEngineCard'\]/);
 assert.match(ui,/audioWrap\.append\(previewGroup,mixerGroup\)/);
 assert.match(ui,/groove\.appendChild\(grooveGroup\)/);
});
test('2.1.0 uses a compact 190px desktop genre column and responsive smaller layouts',()=>{
 assert.match(ui,/#app\{grid-template-columns:190px minmax\(0,1fr\)!important\}/);
 assert.match(ui,/\.genre\{min-height:32px!important/);
 assert.match(ui,/@media\(max-width:900px\)/);
});

test('2.1.0 compacts the sequencer and allocates reclaimed height to Studio panels',()=>{
 assert.match(ui,/#sequencerCard\{flex:0 0 240px!important;min-height:220px!important\}/);
 assert.match(ui,/#bottomGrid\{flex:1 1 auto!important;min-height:220px!important\}/);
 assert.match(ui,/@media\(max-height:760px\)/);
 assert.match(ui,/seq-lane-notes\{min-height:22px!important/);
});
