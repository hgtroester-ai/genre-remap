# Genre Remap 1.9.5.1

Ableton Live MIDI groove transformation extension.

Version 1.9.5.1 adds phrase-aware fill placement and restrained pickups into phrase-ending fills. The release builds on the tested 1.9.4 Groove Dynamics and 1.9.3 Preview Studio foundations while preserving existing manual and interval-based fill placement.

Fill Variation controls use clearer wording: Slight Changes / Varied / Strong Changes; Within Phrase / Across Song / Entire Clip; and Consistent / Position-Based / Building Up. Phrase memory resets at each phrase. Song and clip memory apply across the generated MIDI clip; no memory is shared between separate clips or projects.

The extension is built with the Ableton Extensions SDK. SDK code and trademarks remain the property of Ableton.


## Preview Studio (1.9.3)
Choose **Original** to hear the imported MIDI, **Processed** to hear the transformed groove, or **Compare** to hear both in sequence. Processed playback uses the current genre, remap intensity, Drummer Feel, fill settings and velocity controls. Set the preview volume and BPM, and enable Loop preview for repeated playback.

## Version 1.9.5.1 — Phrase & Fill Engine

Choose **Phrase Endings** in Fill Frequency to place fills at phrase boundaries. The phrase length follows Phrase Builder (4, 8 or 16 bars); if Phrase Builder is set to Original MIDI length, the engine uses 4-bar phrases. A restrained snare pickup leads into each phrase-ending fill; Reggae uses rim/cross-stick instead. Existing manual and fixed-interval placement remain available, and the established Punk fill sequence is unchanged.

## Version 1.9.4 — Groove Dynamics
The Groove Dynamics panel adds three independent controls:
- **Ghost Notes (0–100%)**: adds restrained offbeat snare ghosts in Funk, Hip-Hop and Blues Rock. Default: 0%.
- **Accents (0–100%)**: increases the difference between downbeats/backbeats and lighter subdivisions. Default: 35%.
- **Humanize (0–100%)**: adds deterministic micro-timing and velocity variation. Timing is limited to approximately ±0.02 beats. Default: 0%.

These settings affect the processed Preview Studio playback, sequencer display and MIDI clip created in Ableton Live. The Original preview remains the source performance (with the existing velocity scaling controls only).


## Groove Intelligence 1.9.6.0
Groove Intelligence analyses the source MIDI timing before applying restrained target-genre timing rules. Auto preserves part of the source's measured role timing and swing tendency. The eight genre profiles use bounded timing offsets; downbeat kick anchors and core backbeats are protected. Controls: Timing Feel, Groove Amount, Swing Amount and Preserve Original Groove (High/Medium/Low). This first implementation is deterministic and should be auditioned with varied source MIDI files before relying on it for final arrangements.


## Sequencer Improvements 1.9.8.0

- Clear four-beat ruler inside every bar, with phrase-boundary shading.
- Visual grid options from 1/32 to 1/4 and timeline zoom from 75% to 150%.
- Sequencer view supports 1–16 bars; horizontal scrolling is enabled only when needed.
- This release improves visualization only; direct MIDI note editing is the next development stage.

## Phrase-aware Groove Intelligence 1.9.7.0
Adds Stable, Moderate and Evolving phrase development with automatic or explicit 4-, 8- and 16-bar cycles. Phrase development is deterministic and deliberately avoids moving primary kick downbeats and snare backbeats. It runs after the existing fill engine and is included in the processed preview and MIDI export path.


## Audio Preview – 1.9.9.0
The preview now embeds the original ten WAV drum samples from the Genre Konverter sample bank. Each WAV contains four velocity layers. Playback applies the corresponding layer, calibrated gain, peak protection, stereo lane positioning and a master compressor. The Remap phrase scheduler and MIDI transformation/export paths remain in place.


## Drum Mixer – 1.9.10.0

The preview includes a foldable 10-channel mixer for Kick, Snare, Rim, Low/Mid/Hi Tom, Closed/Open Hat, Crash and Ride. Each channel has a 0–150% level trim, Mute and Solo. Multiple Solo channels can be active; Mute takes priority. Reset Mixer restores 100% levels and clears Mute/Solo; Clear Mute/Solo keeps levels; Mixer Bypass restores the calibrated pre-mixer balance. Mixer state is saved with the extension settings and applies to Original, Processed and Compare preview only. It never changes exported MIDI.
