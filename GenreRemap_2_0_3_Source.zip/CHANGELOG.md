# Genre Remap 2.0.0 — Studio Interface

## GUI redesign
- Compact left genre navigation: 190 px base width, tighter buttons and spacing; full genre names retained.
- New REMAP / GROOVE / AUDIO tabs for the existing settings.
- Remap tab groups target/clip destination, remap intensity and Fill Engine.
- Groove tab groups Velocity Intelligence, Groove Dynamics and Groove Intelligence.
- Audio tab groups Original / Processed / Compare, Preview Volume, Drum Mixer, tempo and preview controls.
- Sequencer receives the flexible central area; settings scroll within their own panel instead of forcing the whole extension to scroll.
- Existing controls are moved, not recreated; IDs and control logic remain unchanged.

## Preserved
- MIDI transformation, phrase/fill processing and MIDI clip creation.
- Velocity layer selection and sensitivity.
- Original / Processed / Compare audio preview and ten-channel mixer.
- Existing settings persistence and mapping behavior.

## Validation
- See build and test results accompanying this release.
- Actual Ableton Live runtime and listening test still required on the user's Mac.
# Changelog

## 1.9.5 — Phrase & Fill Engine
- Added **Phrase Endings** as a Fill Frequency option. Fills are placed at each 4-, 8- or 16-bar phrase boundary, following the selected Phrase Builder length; when Phrase Builder remains at Original MIDI length, the default phrase length is 4 bars.
- Added a restrained phrase pickup before each phrase-ending fill: a quiet snare pickup, or rim/cross-stick in Reggae, helps lead into the fill. Existing notes are preserved and duplicate pickup notes are avoided.
- Phrase-end fill variants use the existing variation memory and drummer-profile logic, so repeated phrases can vary without losing the selected style.
- Existing manual and fixed-interval fill placement remains available. The established Punk fill sequence is deliberately left unchanged.
- Retained Groove Dynamics, Preview Studio, clip-slot safety, and existing genre-specific fill branches.


## 1.9.3 — Preview Studio
- Added Preview Mode selector: Original, Processed and Compare.
- Original plays the loaded source MIDI; Processed plays the transformed MIDI including genre remap, selected Drummer Feel, fills and velocity controls.
- Compare plays Original first and Processed second, separated by a short pause.
- Compare and loop timing are aligned to the phrase length and selected BPM.
- Preview mode can be changed during playback; the preview restarts cleanly in the new mode.
- Kept the existing embedded drum samples, volume control, tempo control and loop option.


- Renamed Variation Strength choices to Slight Changes / Varied / Strong Changes.
- Renamed Variation Memory choices to Within Phrase / Across Song / Entire Clip. Phrase memory now resets its no-repeat set at each phrase boundary.
- Renamed Dynamic Variation choices to Consistent / Position-Based / Building Up.
- Added concise explanations to the Fill Variation controls; internal setting values remain compatible.
- No changes to genre definitions, Punk fill patterns, clip targeting, or MIDI destination behavior.

## 1.9.1 — Fill-Variation-Index-Fix

- Fixed crash when Fill Variation uses 16 variants but the alternating-map library contains 8 base maps. Variant indices now wrap safely across the available maps.
- Added a regression test covering 16 variants across a long arrangement.
- No changes to genre definitions, Punk fill patterns, clip targeting, or GUI layout.

## 1.9.0 — Clip destination regression fix

- Restore Ableton's context-menu ClipSlot handle as the primary destination: the clip slot clicked by the user is used.
- Use the track/slot shown in the window only as a fallback when the context-menu handle cannot be resolved.
- Restore clip creation, MIDI-note assignment, and clip naming to the same Ableton transaction.
- Retain the 1.8.9 sequencer redraw coalescing, processed-MIDI cache, preview recovery, genre rules, Fill Engine, Punk fills, Phrase Builder, and GUI layout.

## 1.8.9 — Stability & Performance

- Coalesce sequencer redraws to one animation frame during rapid control changes.
- Cache processed MIDI results by source and transformation settings to avoid repeated full remaps.
- Recover preview initialization after sample decode failures; validate sample availability and report unmapped preview notes.
- Use the explicitly selected MIDI track/clip slot before a context-menu fallback.
- Create the MIDI clip and assign notes in separate transaction steps; surface the underlying Ableton error.
- Preserve genre rules, Fill Engine, Punk fills and GUI layout.

# Changelog

## 1.8.8
- Unified Fill Engine and Fill Variation inside one shared outer card.
- Removed the separate inner frame around Fill Variation; retained its heading and subtle divider.
- Allowed the Fill Engine card to grow naturally so its variation controls remain inside the same frame without clipping or overflow.
- No MIDI generation or fill-engine behavior changes.


## 1.8.3
- Fixed malformed settings-panel markup that detached Fill Engine, Velocity & Preview, and Action from the five-column settings grid.
- Reworked the lower settings area to use the available width with compact, two-column Fill Engine controls.
- Reduced vertical padding and control sizes to minimize scrolling and prevent overlapping panels.
- Added responsive layouts for narrower extension windows.


## 1.8.2
- Moved Fill Engine into its own full-width settings column; removed redundant lower-left sidebar footer.
- Added Fill Style Variation Manager controls: Balanced strength, Song memory, Progressive dynamics as defaults.
- Expanded deterministic variation selection up to 16 combinations and applied variation selection across non-Punk fill styles.
- Kept Punk fill branch protected from the new variation manager.
- Preserved Phrase Builder and existing clip-length behavior.


## 1.8.1
- Added Phrase Builder: expand short MIDI grooves to 4, 8, or 16 bars, or retain original length.
- Repeated phrases preserve the source groove while adding restrained, deterministic velocity movement shaped by Drummer Feel.
- When Phrase Builder is active and Fill is enabled, a fill is guaranteed in the final phrase bar, including Manual fill mode.
- Final phrase fill does not add an unintended landing bar.
- Existing Classic mode and Punk fill branch remain available.

# Changelog

## 1.8.0
- Added a separate Intelligent Fill Generator for Funk and Classic Rock.
- Added deterministic song-local variation across rhythm and instrument contours.
- Retained the classic fill engine as a selectable fallback.
- Punk continues to use the established legacy fill branch.

## 1.7.3 — Fill Variation Manager
- Added deterministic song-local fill variant selection for balanced variation across repeated interval fills.
- The final interval fill uses the normal variation sequence rather than a forced special-ending contour.
- Preserved the Punk fill branch and existing fill-engine settings.

## 1.7.2 — Correct 8-bar phrase detection

- Count musical bars from the last note onset, not a note-off that barely crosses the bar boundary. This keeps the supplied 8-bar Funk verse at 8 bars when its final note ends 3 ticks beyond the boundary.
- Keep fill placement and ending-fill behavior unchanged; no changes to Punk fill patterns.

# Genre Remap 1.6.1

- Fixed a fatal initialization-order bug in the UI script: remap intensity initialization called `syncRemapLevel()`, which called `renderSequencer()` before `parsed` had been initialized. In JavaScript this triggered a temporal-dead-zone `ReferenceError` and stopped the remainder of UI initialization.
- Moved initial intensity synchronization to after the declarations of `SAVED`, `parsed`, and `selectedGenre`.
- Updated version metadata and labels to 1.6.1.
- No changes to the Fill Engine implementation or Punk fill rules.

## 1.7.1 — Fill bar counting and ending-fill boundary
- Fixed the final-bar landing behavior: when the song-ending fill is on the last bar, no kick/crash landing is inserted beyond the song boundary and the clip is not extended by one extra bar.
- Kept next-bar kick/crash landings for non-final interval fills and for manually selected fills.
- Added regression tests confirming an 8-bar song fills bar 8 (beats 8.1–8.4) and remains 8 bars long when the ending-fill option is enabled.
- Existing Fill Engine and Punk fill branch were not modified.

## 1.7.1 — Ignore trailing silent MIDI track time
- Fixed song-length detection to use the latest actual note end, rather than the MIDI track's final event/EOT time. Some MIDI files contain an extra silent tail, which was incorrectly counted as an additional bar.
- Fill Landing and Ending Fill checkboxes remain independent; neither setting is required to prevent a trailing silent bar from extending the created clip.
- Fill Engine patterns and Punk-specific fill logic unchanged.

## 1.8.4
- Moved Create Genre Remix, Preview, Reset and Cancel into the left sidebar directly below Target Genre.
- Removed the separate Action card from the bottom settings grid, reclaiming horizontal space for the four remaining settings areas.
- Made the sidebar independently scrollable when its content exceeds the available height; main panel retains its own vertical scrolling.
- Kept MIDI processing, Fill Engine and generator behavior unchanged.


## 1.8.5
- Grouped Variation Strength, Variation Memory and Dynamic Variation in a single framed Fill Variation panel.
- Placed all three controls on one horizontal row with a shared heading and explanatory text.
- Kept the selected defaults: Balanced / Song / Progressive.
- No fill-generation, MIDI transformation, or Punk-fill behavior changed.

## 1.8.8 – Stability recovery
- Rebased on the last user-tested stable 1.8.6 source.
- Reverted the 1.8.7 sequencer caching, deferred refresh and per-bar diff changes that preceded the reported complete UI failure.
- Preserved the target genre list, existing Fill Engine, Fill Variation panel, Phrase Builder and established MIDI processing behavior.
- This recovery release prioritizes startup reliability over the experimental sequencer optimization.

## 1.9.4 — Groove Dynamics
- Added independent Ghost Notes, Accents and Humanize controls alongside the existing Overall/Kick/Snare/Hi-Hat velocity controls.
- Groove dynamics are applied to the processed groove in Preview Studio, the sequencer and the MIDI clip sent to Ableton Live.
- Ghost-note generation is restrained and genre-aware (Funk, Hip-Hop and Blues Rock); it is off by default to preserve the 1.9.3 sound unless enabled.
- Accent shaping emphasizes kick downbeats, snare backbeats and selected hi-hat pulses.
- Humanize adds deterministic, repeatable micro-timing (maximum approximately ±0.02 beats) and small velocity variation. It is off by default.
- Existing 1.9.3 Preview Studio modes and clip-slot safety behavior are retained.


## 1.9.5.1 — Layout and window-size correction
- Based strictly on the confirmed working 1.9.5 source; no MIDI processing, genre, drag-and-drop, or Finder logic changed.
- Increased the Ableton dialog size from 1450 × 900 to 1680 × 1050.
- Widened the settings columns and improved text wrapping in Remap Settings, Fill Engine, Fill Variation, and Velocity & Preview.
- Increased spacing and minimum widths to prevent labels and descriptions from colliding.


## 1.9.6.0 — Groove Intelligence (initial implementation)
- Added source-groove analysis for role-based timing offsets and eighth-note swing tendency.
- Added genre-aware timing profiles for Classic Rock, Blues Rock, Alternative Rock, Punk, Funk, Hip-Hop, Reggae and Ska.
- Added Timing Feel (Auto, Straight, Swing, Shuffle, Laid-back, Push), Groove Amount, Swing Amount and Preserve Original Groove controls.
- Auto blends source timing character with target-genre timing; downbeat kick anchors and core backbeats are protected.
- Groove settings are included in preview/processed caching and saved settings.
- Based on the confirmed 1.9.5.1 source; no changes to MIDI file loading, drag-and-drop, target genre selection, clip destination or Ableton clip creation.
- This is an initial timing engine; real-world musical evaluation in Ableton remains necessary.


## 1.9.7.0 — Adaptive Phrase-aware Groove Intelligence
- Added phrase development modes: Stable, Moderate and Evolving.
- Added automatic or explicit 4-, 8- and 16-bar phrase cycles.
- Phrase-aware variation applies restrained, deterministic movement to non-anchor notes and velocity contours.
- Main kick downbeats and primary snare backbeats remain protected.
- Applied after the existing fill engine so the same result is used by preview, sequencer and MIDI export.
- No changes to MIDI file loading, Target Genre construction, drag-and-drop, Finder, or Ableton clip targeting.


## 1.9.8.0 — Sequencer Improvements (Step A)

- Reworked the ruler to show beats 1–4 clearly inside every bar.
- Added phrase-start and phrase-end visual guides based on the selected phrase length.
- Added 1/32 visual grid and timeline zoom (75%, 100%, 125%, 150%).
- Expanded visible range to 1–16 bars; horizontal scrolling is used only when required by bar count or zoom.
- Preserved Original / Processed / Compare views and the existing note-generation pipeline.
- Direct note editing is intentionally not included in this step; this release establishes the clearer editor-like timeline first.


## 1.9.9.0 – WAV Audio Engine Integration
- Replaced the MP3 preview assets with the ten original embedded WAV drum samples from Genre Konverter 9.5.x.
- Restored four velocity layers per sample, layer gain calibration, continuous velocity contour, per-hit peak protection and short fade-in.
- Added lane-specific stereo panning and a master dynamics compressor.
- Preserved Original / Processed / Compare, loop, Stop, Preview Volume, BPM and MIDI transformation paths.
- The existing Remap phrase scheduler is intentionally retained; the Genre Konverter short-lookahead transport is not yet ported.


## 1.9.10.0 – Drum Mixer
- Added a foldable 10-channel preview mixer: Kick, Snare, Rim, Low Tom, Mid Tom, Hi Tom, Closed Hat, Open Hat, Crash and Ride.
- Added independent 0–150% channel level trims, Mute and multi-channel Solo. Mute takes priority over Solo.
- Added Reset Mixer, Clear Mute / Solo and Mixer Bypass.
- Mixer settings persist with extension settings and are shared by Original, Processed and Compare preview modes.
- Mixer controls affect preview audio only; MIDI transformation and exported clip data are unchanged.

## 1.9.11.0 — Velocity Intelligence & Sample Selection
- Added Natural, Balanced (default) and Expressive preview velocity modes.
- Added adjustable velocity sensitivity (0–150%) and persisted both controls in settings.
- Kept the four original WAV velocity segments and their calibrated per-lane gain tables.
- Added a narrow equal-power crossfade between adjacent velocity layers around the existing 50/80/105 boundaries to reduce abrupt transitions.
- Kept MIDI transformation/export, Original / Processed / Compare scheduling and the 1.9.10 Drum Mixer routing unchanged.
- Explicitly documented that the current embedded WAVs do not contain independent Round-Robin takes; no artificial sample variation is claimed or generated.
- Validation: automated regression tests and portable package checks; no Ableton Live runtime/listening test performed here.

## 2.0.1 — Compact Sequencer
- Reduced sequencer target height to 240px (210px on short windows).
- Tightened lane rows, note rows, metadata and legend spacing while retaining grid, note visibility, playhead, tabs and controls.
- Studio settings area uses reclaimed vertical space.
- No MIDI transformation, audio engine, sample assets, mixer or export logic changed.
- Build and automated regression checks; Ableton runtime/listening test remains user-side.

## 2.0.3 — Compact Audio Engine (MP3 320)
- Re-encoded the ten embedded stereo 44.1 kHz float WAV preview samples to high-quality 320 kbit/s MP3 for the installable runtime.
- Kept the original WAV masters in `assets/original-wav/` in the source archive.
- Preserved each encoded sample duration at 2.926848 s in the ffmpeg round-trip, so the four equal velocity-layer time regions remain aligned by duration.
- Web Audio continues to decode the embedded audio through `decodeAudioData`; MIDI transformation/export and mixer processing were not changed.
- MP3 is lossy: this is a candidate build for user listening tests, not a claim of transparent or lossless audio.
